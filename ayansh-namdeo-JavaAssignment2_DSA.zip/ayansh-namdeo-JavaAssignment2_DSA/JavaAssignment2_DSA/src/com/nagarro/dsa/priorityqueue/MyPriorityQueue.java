package com.nagarro.dsa.priorityqueue;

import com.nagarro.dsa.exception.LinkedListException;
import com.nagarro.dsa.exception.PriorityQueueException;
import com.nagarro.dsa.iterator.Iterator;
import com.nagarro.dsa.iterator.Iterable;

public class MyPriorityQueue implements Iterable {
	private int size;
	private Node start;

	public class Node {
		private int data;
		private int priority;
		private Node next;

		public Node(int data, int priority) {
			this.data = data;
			this.priority = priority;
			this.next = null;
		}
	}

	public void Enqueue(int val, int priority) {
		Node node = new Node(val, priority);
		size++;
		if (start == null)
			start = node;
		else if (start.priority < node.priority) {
			node.next = start;
			start = node;
		} else {
			Node temp;
			temp = start;
			while (temp.next != null && temp.next.priority > node.priority) {
				temp = temp.next;
			}
			node.next = temp.next;
			temp.next = node;

		}
	}

	public void dequeue() {
		if (start == null)
			System.out.println("Underflow Condition");
		else
			start = start.next;
		size--;
	}

	public Integer peek() {
		if (underFlow())
			return null;
		else {
			return start.data;
		}
	}

	public boolean Contains(int element) {
		if (underFlow())
			throw new PriorityQueueException("List is Empty");
		Node temp;
		temp = start;
		while (temp != null) {
			if (temp.data == element)
				return true;
			temp = temp.next;
		}

		return false;
	}

	public void center() {
		int count = 0;

		Node prev = start;

		// Find length of a linked list
		while (prev != null) {
			prev = prev.next;
			count++;
		}

		// Intialized, again with head pointer
		prev = start;
		int mid = 0;

		while (mid < count / 2) {

			prev = prev.next;
			mid++;
		}

		System.out.println(prev.data);
	}

	public void size() {
		System.out.println(size);
	}

	public void viewList() {
		Node temp;
		if (underFlow())
			throw new PriorityQueueException("List is Empty");
		else {
			temp = start;
			while (temp != null) {
				System.out.print(" " + temp.data);
				temp = temp.next;
			}
		}
	}

	public void reverse() {
		if (underFlow()) {
			throw new PriorityQueueException("List is Empty");
		}
		Node previous = null;
		Node next = null;
		Node temp = start;
		if (size == 1)
			return;
		while (temp != null) {
			next = temp.next;
			temp.next = previous;
			previous = temp;
			temp = next;
		}
		start = previous;
	}

	public boolean underFlow() {
		return start == null;
	}
	@Override
	public Iterator iterator() {
		return new Iterator() {
			Node temp = start;

			@Override
			public int next() {
				int t = temp.data;
				temp = temp.next;
				// TODO Auto-generated method stub
				return t;
			}

			@Override
			public boolean hasnext() {
				if (underFlow())
					throw new PriorityQueueException("Underflow Condition");
				// TODO Auto-generated method stub

				return temp != null;
			}
		};
	}


}
