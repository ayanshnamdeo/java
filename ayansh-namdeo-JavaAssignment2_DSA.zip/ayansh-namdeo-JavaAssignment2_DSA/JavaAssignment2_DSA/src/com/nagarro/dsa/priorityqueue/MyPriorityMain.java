package com.nagarro.dsa.priorityqueue;

import java.util.Scanner;

import com.nagarro.dsa.iterator.Iterator;



public class MyPriorityMain {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 boolean flag = true;
	Scanner sc = new Scanner(System.in);
	MyPriorityQueue Pqueue = new MyPriorityQueue();
	Pqueue.Enqueue(7, 1);
	Pqueue.Enqueue(2, 4);
	Pqueue.Enqueue(3, 2);
	Pqueue.Enqueue(5, 3);
	Pqueue.Enqueue(1, 9);
	Pqueue.Enqueue(0, 10);
	Pqueue.viewList();
	
	System.out.print("\n size Queue =");
	Pqueue.size();
	
	
	
	while (flag) {
		System.out.println("");
		System.out.println("1. Enqueue item to the PriorityQueue");
		System.out.println("2. Dequeue item to the PriorityQueue");
		System.out.println("3. Peek item to the PriorityQueue");
		System.out.println("4. View List");
		System.out.println("5. Contains item to the PriorityQueue");
		System.out.println("6: Middle Element ");
		System.out.println("7. Size of PriorityQueue");
		System.out.println("8. Reverse Element of PriorityQueue");
		System.out.println("9. Iterate Element of PriorityQueue");
		System.out.println("10. Exit");
		System.out.println("Enter your choice");
		int choice = sc.nextInt();
		int val, priority;
		switch (choice) {
		case 1:
			System.out.println("Enter a value");
			val = sc.nextInt();
			System.out.println("Enter a priority");
			priority = sc.nextInt();
			Pqueue.Enqueue(val, priority);
			break;
		case 2:
			System.out.println("DeQueue element from front");
			Pqueue.dequeue();
			break;

		case 3:
			Integer n = Pqueue.peek();
			System.out.println("peek value is"+n);
		case 4:
			System.out.println("Print list is:");
			Pqueue.viewList();
			break;

		case 5:
			System.out.println("Enter a value");
			val = sc.nextInt();
			System.out.println(Pqueue.Contains(val));
			break;

		case 6:
			System.out.println("Center is:");
			Pqueue.center();
			break;
		case 7:
			System.out.print("Size is:");
			Pqueue.size();
			break;
		case 8:
			System.out.println("Reverse Priority Queue is:");
			Pqueue.reverse();
			break;
		case 9:
			Iterator I = Pqueue.iterator();
			while (I.hasnext()) {
				System.out.println(I.next());
			}
			break;
		case 10:
			flag = false;
			break;
		default:
			System.out.println("Invalid Choice");

		}
	}

}
	}



