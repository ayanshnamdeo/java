package com.nagarro.dsa.stack;


public class Node {
	int data;
	Node next;

}
