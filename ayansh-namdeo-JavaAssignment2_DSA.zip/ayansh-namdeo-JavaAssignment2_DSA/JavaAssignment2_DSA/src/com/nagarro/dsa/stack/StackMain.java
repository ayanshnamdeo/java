package com.nagarro.dsa.stack;

import java.util.Scanner;

import com.nagarro.dsa.iterator.Iterator;
import com.nagarro.dsa.iterator.*;

public class StackMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		MyStack stack = new MyStack();
		
		System.out.println(stack.isEmpty());
		System.out.println("------------------");
		System.out.println(stack.size());
		System.out.println("------------------");

		stack.push(9);
		stack.push(87);
		stack.push(5);
		stack.push(45);
		System.out.println("------------------");
		stack.show();
		System.out.println("------------------");
		System.out.println(stack.contains(87));
		System.out.println("------------------");
		System.out.println(stack.peek());
		System.out.println("------------------");
		stack.pop();
		
		stack.show();
		System.out.println("------------------");
		
		System.out.println(stack.isEmpty());
		
		System.out.println(stack.size());
		System.out.println("------------------");
		stack.center();
		System.out.println("------------------");
		stack.show();
		stack.sort();
		System.out.println("------------------");
		stack.show();
		System.out.println("------------------");
		stack.reverse(stack.top);
		boolean flag = true;
		while (flag) {
			System.out.println("");
			System.out.println("1. Push item to the Stack");
			System.out.println("2. Pop item to the Stack");
			System.out.println("3. Peek item to the Stack");
			System.out.println("4. view List");
			System.out.println("5.Contains element in Stack");
			System.out.println("6. Middle Element in Stack");
			System.out.println("7. Size of Stack");
			System.out.println("8. Sort Element in stack");
			System.out.println("9. Reverse of Element in stack");
			System.out.println("10.Iterate Element in the stack");
			System.out.println("Enter your choice");

			int choice = sc.nextInt();
			int val;
			switch (choice) {
			case 1:
				System.out.println("Enter a value");
				val = sc.nextInt();
				stack.push(val);
				break;
			case 2:
				stack.pop();
				System.out.println("top element is pop: ");
				break;
			case 3:

				Integer n = stack.peek();
				System.out.println("peek element is : " +n);
				break;
			case 4:
				System.out.println("stack is ");
				stack.show();
				break;
			case 5:
				System.out.println("Enter a value");
				val = sc.nextInt();
				System.out.println(stack.contains(val));
				break;
			case 6:
				System.out.print("center value is : ");
				stack.center();
				break;
			case 7: 
				System.out.print("Size is"+stack.size());
				break;
			case 8:
				System.out.println("Sort Stack is :  ");
				stack.sort();
				stack.show();
				break;
			case 9:
				System.out.println("Reverse stack is  : ");
				stack.reverse(stack.top);
				break;
			case 10:
				Iterator I = stack.iterator();
				while (I.hasnext()) {
					System.out.println(I.next());
				}
				break;
			case 11:
				flag = false;
				System.out.println("thank you");
				break;
				
			default:
				System.out.println("invalid case");

			}
		}
	}
		
		

	}



