package com.nagarro.dsa.stack;

import com.nagarro.dsa.exception.*;
import com.nagarro.dsa.iterator.*;
import com.nagarro.dsa.iterator.Iterable;

public class MyStack implements Iterable {
	Node top;
	int size;
	public MyStack() {
		
		top=null;
		size=0;
	}
	
	public void push(int data) {
		Node temp=new Node();
		temp.data=data;
		temp.next=top;
		size++;
		top=temp;
		
		
		
	}
	
	public int peek() {
		if(isEmpty()) {
			throw new StackException("Stack is Empty");
		}
		return top.data;

		}
	
	public int pop() {
		if(isEmpty()) {
			throw new StackException("Stack is Empty");
		}
		int res=top.data;
		top=top.next;
		size--;
		
		return res;
		
	}
	
	public boolean contains(int element) {
		if (isEmpty()) {
			throw new StackException("Stack is Empty");
		}
		Node temp;
		boolean flag=false;
		temp = top;
		while (temp != null) {
			if (temp.data == element) {
				flag=true;
			}
			temp = temp.next;
		}
		return flag;
	}
	
	public boolean isEmpty() 
	{
		return size==0;//top==null
	}
	public int size()
	{
		return size;
	}
	public void center() {
		 int count =0;
		 
		   Node prev = top;
		 
		   //Find length of a linked list
		   while (prev !=null){
		       prev = prev.next;
		       count++;
		   }
		 
		   //Intialized, again with head pointer
		   prev= top;
		   int mid = 0;
		 
		   while (mid < count/2){
		 
		      prev = prev.next;
		      mid++;
		   }
		 
		   System.out.println(prev.data);
	 }
	 public void sort() {
		 Node prev=top;
		 Node index=null;
		 
		 int temp;
		 if(top == null) {
			 return;
		 }
		 else {
			 
		 while(prev!=null) {
			 index=prev.next;
			 while(index!=null) {
			 if(prev.data>index.data) {
				 temp=prev.data;
				 prev.data=index.data;
				 index.data=temp;
			 }
			 index=index.next;
			 }
			 prev=prev.next;
		 	 }
	 }
		 }
	 public void reverse(Node top) {
		 
	        if (top == null) return;
	 
	        // print list of head node
	        reverse(top.next);
	 
	        // After everything else is printed
	        System.out.println(top.data +" ");
	    }
	
	
	public void show() {
		Node curr=top;
		while(curr!=null) {
			System.out.println(curr.data);
			curr=curr.next;
		}
	}
	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return new Iterator() {
			Node temp = top;

			public int next() {
				int t = temp.data;
				temp = temp.next;
				// TODO Auto-generated method stub
				return t;
			}

			@Override
			public boolean hasnext() {
				if (isEmpty()) {
					throw new StackException("Queue is Empty");
				}
				// TODO Auto-generated method stub

				return temp != null;
			}
		};
	}

}
