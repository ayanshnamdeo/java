package com.nagarro.dsa.exception;

public class StackException extends RuntimeException {
	public StackException(String s) {
		System.out.println(s);
	}

}
