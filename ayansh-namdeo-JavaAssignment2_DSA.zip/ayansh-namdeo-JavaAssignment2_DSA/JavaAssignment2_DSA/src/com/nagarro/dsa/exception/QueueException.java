package com.nagarro.dsa.exception;

public class QueueException extends RuntimeException {
	public QueueException(String s) {
		System.out.println(s);
	}

}
