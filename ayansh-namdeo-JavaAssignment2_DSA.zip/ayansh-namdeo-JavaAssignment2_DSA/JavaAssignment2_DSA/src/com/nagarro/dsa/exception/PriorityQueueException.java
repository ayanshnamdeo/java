package com.nagarro.dsa.exception;

public class PriorityQueueException extends RuntimeException {
	public PriorityQueueException(String s) {
		System.out.println(s);
	}

}



