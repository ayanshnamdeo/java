package com.nagarro.dsa.exception;

public class LinkedListException extends RuntimeException {
	public LinkedListException(String m) {
		System.out.println("ListIsEmptyException : " + m);
	
	}
}
