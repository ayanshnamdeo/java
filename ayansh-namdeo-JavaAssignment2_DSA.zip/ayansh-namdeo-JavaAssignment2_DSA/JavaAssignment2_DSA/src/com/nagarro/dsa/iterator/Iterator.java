package com.nagarro.dsa.iterator;

public interface Iterator {
	
	public boolean hasnext();

	public int next();

}
