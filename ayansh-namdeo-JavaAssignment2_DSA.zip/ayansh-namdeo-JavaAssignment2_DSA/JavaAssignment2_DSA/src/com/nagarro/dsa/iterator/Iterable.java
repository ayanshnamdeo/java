package com.nagarro.dsa.iterator;

public interface Iterable {
	public Iterator iterator();

}
