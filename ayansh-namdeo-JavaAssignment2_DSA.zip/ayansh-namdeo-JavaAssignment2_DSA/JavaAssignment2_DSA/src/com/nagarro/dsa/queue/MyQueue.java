package com.nagarro.dsa.queue;

import com.nagarro.dsa.exception.*;
import com.nagarro.dsa.iterator.*;
import com.nagarro.dsa.iterator.Iterable;
import com.nagarro.dsa.iterator.Iterator;

public class MyQueue implements Iterable {
	Node front;
	Node Rear;
	int length=0;
	


	
	public void enQueue(int data) {
		Node newnode= new Node();
		newnode.data=data;
		newnode.next=null;
		if(front == null) {
			front= Rear =newnode;
		}
		else {
			Rear.next=newnode;
			Rear=newnode;
		}
		
		length++;
	}
	
	public int deQueue() {
		if(front !=null) {
			int res=front.data;
			front=front.next;
			length--;
			return res;
			
		}
		return 0;
	}
	public boolean contains(int element) {
		if (front==null)
			throw new QueueException("List is Empty");
		Node temp;
		temp = front;
		while (temp != null) {
			if (temp.data == element)
				return true;
			temp = temp.next;
		}

		return false;
	}
	
	public int size() {
		return length;
	}
	public void center() {
		 int count =0;
		 
		   Node prev = front;
		 
		   //Find length of a linked list
		   while (prev !=null){
		       prev = prev.next;
		       count++;
		   }
		 
		   //Intialized, again with head pointer
		   prev= front;
		   int mid = 0;
		 
		   while (mid < count/2){
		 
		      prev = prev.next;
		      mid++;
		   }
		 
		   System.out.println(prev.data);
	 }
	public boolean isEmpty() 
	{
		return length==0;//top==null
	}
	
	public int peek() {
		if(isEmpty()) {
			throw new QueueException("List is Empty");
		}
		return front.data;

		}
	
	public void sort() {
		 Node prev=front;
		 Node index=null;
		 
		 int temp;
		 if(front == null) {
			 return;
		 }
		 else {
			 
		 while(prev!=null) {
			 index=prev.next;
			 while(index!=null) {
			 if(prev.data>index.data) {
				 temp=prev.data;
				 prev.data=index.data;
				 index.data=temp;
			 }
			 index=index.next;
			 }
			 prev=prev.next;
		 	 }
	 }
		 Node curr=front;
			while(curr!=null) {
				System.out.println(" " +curr.data);
		
				curr=curr.next;
			}
		 
		 }
	
	public void reverse(Node front) {
		 
        if (front == null) return;
 
        // print list of head node
        reverse(front.next);
 
        // After everything else is printed
        System.out.println(front.data +" ");
    }
	
	
	public void display() {
		Node curr=front;
		while(curr!=null) {
			System.out.println(" " +curr.data);
	
			curr=curr.next;
		}
	}
	
	public boolean underFlow() {
		return front == null;
	}

	@Override
	public Iterator iterator() {
		// TODO Auto-generated method stub
		return new Iterator() {
			Node temp = front;

			public int next() {
				int t = temp.data;
				temp = temp.next;
				// TODO Auto-generated method stub
				return t;
			}

			@Override
			public boolean hasnext() {
				if (underFlow()) {
					throw new QueueException("List is Empty");
				}
				// TODO Auto-generated method stub

				return temp != null;
			}
		};
	}

}
