package com.nagarro.dsa.queue;

import java.util.Scanner;

import com.nagarro.dsa.iterator.*;




public class QueueMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		MyQueue q = new MyQueue();
		boolean flag = true;
		
		

		q.enQueue(24);
		q.enQueue(18);
		q.enQueue(27);
		q.enQueue(36);
	
		q.display();
		
		System.out.println("------------------");
		System.out.println( "is empty ? "+q.isEmpty());
		
		while (flag) {
			System.out.println("");
			System.out.println("1. Insert item to the Queue");
			System.out.println("2. Delete item to the Queue");
			System.out.println("3. Peek item to the Queue");
			System.out.println("4. View List");
			System.out.println("5. Contains item to the Queue");
			System.out.println("6. Size of Queue");
			System.out.println("7. Middle Element in the Queue");
			System.out.println("8. Reverse Element of Queue");
			System.out.println("9. Sort Element of Queue");
			System.out.println("10.Iterate Element in the Queue");
			System.out.println("11. Exit");
			System.out.println("Enter your choice");
			int choice = sc.nextInt();
			int val;
			switch (choice) {
			case 1:
				System.out.println("Enter a value");
				val = sc.nextInt();
				q.enQueue(val);
				break;
			case 2:
				System.out.println("Dequeue from front:");
				q.deQueue();
				break;
			case 3:
				Integer n = q.peek();
				System.out.println("peek element is:"+n);
			case 4:
				q.display();
				break;
			case 5:
				System.out.println("Enter a value");
				val = sc.nextInt();
				System.out.println(q.contains(val));
				break;
			case 6:
				System.out.println("size is :"+q.size()); 
				break;
			case 7:
				System.out.print("Center is ");
				q.center();
				break;
			case 8:
				System.out.println("reverse queue is:");
				q.reverse(q.front);
				break;
			case 9:
				System.out.println("sort queue is:");
				q.sort();
				break;
			case 10:
				Iterator I = q.iterator();
				while (I.hasnext()) {
					System.out.println(I.next());
				}
				break;	
			case 11:
				flag = false;
				System.out.println("Thank you");
				break;
			default:
				System.out.println("Invalid Choice");

			}
		}
	}
		
}


