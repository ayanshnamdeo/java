package com.nagarro.dsa.queue;



public class Node {
	int data;
	Node next;

}
