package com.nagarro.dsa.Linkedlist;

public class Node {

		int data;
		Node next;

	}

