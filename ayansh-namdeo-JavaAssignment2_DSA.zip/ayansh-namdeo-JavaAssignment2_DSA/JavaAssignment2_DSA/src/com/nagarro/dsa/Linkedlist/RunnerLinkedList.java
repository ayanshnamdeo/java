package com.nagarro.dsa.Linkedlist;

import java.util.Scanner;
import com.nagarro.dsa.iterator.*;


public class RunnerLinkedList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			boolean flag = true;
			Scanner sc = new Scanner(System.in);
			LinkedList list = new LinkedList();
			
			list.insert(32);
			list.insert(45);
			list.insert(98);
			list.show();
			
			
			
			
		
			

		
		
			
			
			
			

			

			while (flag) {
				System.out.println("");
				System.out.println("1. Add item into the list");
				System.out.println("2. Add item to the list at End");
				System.out.println("3. Add item to the list at Position");
				System.out.println("4. Delete item to the list at position");
				System.out.println("5. Delete item to the list at End");
				System.out.println("6. View List");
				System.out.println("7. Search Middle Element");
				System.out.println("8. List Size");
				System.out.println("9. Sort Element in list");
				System.out.println("10. Reverse Element in list");
				System.out.println("11. Iterate a list Element");
				System.out.println("12. Exit");
				System.out.println("Enter your choice");
				int choice = sc.nextInt();
				int position, val,indx;
				switch (choice) {
				case 1:
					System.out.println("Enter value to add item on list randomly ");
					val = sc.nextInt();
					list.insert(val);
					break;

				case 2:
					System.out.println("Enter value to the list at End");
					val = sc.nextInt();
					list.insertEnd(val);
					break;

				case 3:
					System.out.println("Enter index to add the list at Position");
					indx = sc.nextInt();
					System.out.println("Enter value to add value the list ");
					val = sc.nextInt();
					list.insertAt(val, indx);
					break;

				case 4:
					System.out.println("Enter index to delete value");
					indx = sc.nextInt();
					list.delete(indx);
					break;

				case 5:
					list.deleteEnd();
					break;

				case 6:
					list.show();
					break;

				case 7:
					
					list.center();
					break;
				case 8:
					list.size();
					break;
				/*case 9:
					System.out.println("Enter a value");
					val = sc.nextInt();
					System.out.println(list.contains(val));
					break;*/
				case 9:
					list.sort();
					list.show();
					break;
				case 10:
					list.reverse(list.head);
					break;
				case 11:
					Iterator I = list.iterator();
					while (I.hasnext())
						System.out.println(I.next());
					break;
					
				case 12:
					flag = false;
					System.out.println("thank you");
					break;

				default:
					System.out.println("Invalid Choice");
					
					}


				}
			}
	}


