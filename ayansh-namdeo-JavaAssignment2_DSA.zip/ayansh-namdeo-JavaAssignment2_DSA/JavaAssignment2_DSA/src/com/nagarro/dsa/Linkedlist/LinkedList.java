package com.nagarro.dsa.Linkedlist;

import com.nagarro.dsa.exception.*;
import com.nagarro.dsa.iterator.*;
import com.nagarro.dsa.iterator.Iterable;

public class LinkedList implements Iterable {
	Node head;
	 public void insert(int data) {
		    Node node=new Node();
			node.data = data;
			node.next = null;
			if(head == null) {
				head=node;
			}
			else {
				Node n=head;
				while(n.next !=null) {
					n=n.next;
				}
				n.next=node;
			}
	 }
	 
	 public void insertAt(int data, int indx) {
		Node toAdd=new Node();
			toAdd.data=data;
			if(head==null) {
				head=toAdd;
				return;
			}
			
			else if(indx == 0) {
			 toAdd.next=head;
			 head=toAdd;
			 
		 }
		 else {
		 Node prev = head;
		 for(int i=0;i<indx-1;i++) {
			 prev=prev.next;
		 }
		 toAdd.next=prev.next;
		 prev.next=toAdd;
		 
			}}
		 
	 
	 public void insertEnd(int data) {
		 Node prev=head;
		 Node last=new Node();
		 last.data=data;
		 prev=prev.next;
		 if (head==null) {
				throw new LinkedListException("List is Empty");
			} 
		 
		 while(prev.next!=null) {
			 prev=prev.next;
		 }
		 if(prev.next==null) {
			 
			 prev.next=last;
			 last.next=null;
		 }
		 
	 }
	 
	 public void show() {
		 Node node=head;
		 while(node !=null) {
			 System.out.println(node.data);
			 node=node.next;
		 }
		 //System.out.println(node.data);
	 }
	 
	 public void delete(int indx) {
		 if(indx==0) {
			 head=head.next;
		 }
		 else {
		 Node prev=head;
		 for(int i=0;i<indx-1;i++) {
			 prev=prev.next;
		 }
		 prev.next=prev.next.next;
	 }}
	 
	 public void deleteEnd() {
		 Node prev=head;
		 Node index=head;
		 while(prev.next!=null) {
			 prev=prev.next;
			 }
		 while(index.next!=prev)
		 {
		    index=index.next;	 
		 }
		 index.next=null;
		 }
	 
	 public void size()
	 {
		 int count=0;
		 Node prev=head;
		 while(prev!=null) {
			 prev=prev.next;
			 count++;
		 }
		 System.out.println("size is "+count);
		 
	 }
	 public void center() {
		 int count =0;
		 
		   Node prev = head;
		 
		   //Find length of a linked list
		   while (prev !=null){
		       prev = prev.next;
		       count++;
		   }
		 
		   //Intialized, again with head pointer
		   prev= head;
		   int mid = 0;
		 
		   while (mid < count/2){
		 
		      prev = prev.next;
		      mid++;
		   }
		 
		   System.out.println("Center is "+prev.data);
	 }
	 
	    
		 
		 
	 
	 public void sort() {
		 Node prev=head;
		 Node index=null;
		 
		 int temp;
		 if(head == null) {
			 return;
		 }
		 else {
			 
		 while(prev!=null) {
			 index=prev.next;
			 while(index!=null) {
			 if(prev.data>index.data) {
				 temp=prev.data;
				 prev.data=index.data;
				 index.data=temp;
			 }
			 index=index.next;
			 }
			 prev=prev.next;
		 	 }
	 }
		 }
	 
		 
		 

	 public void reverse(Node head) {
		 
		        if (head == null) return;
		 
		        // print list of head node
		        reverse(head.next);
		 
		        // After everything else is printed
		        System.out.print( head.data +" ");
		    }
	 public boolean isEmpty() {
			return head == null;
		}
	 @Override
		public Iterator iterator() {
			return new Iterator() {
				Node temp = head;

				@Override
				public int next() {
					int t = temp.data;
					temp = temp.next;
					return t; // naming

				}

				@Override
				public boolean hasnext() {
					if (isEmpty()) {
						throw new LinkedListException("List is Empty");
					}

					return temp != null;
				}
			};
		}


	 
	
}
