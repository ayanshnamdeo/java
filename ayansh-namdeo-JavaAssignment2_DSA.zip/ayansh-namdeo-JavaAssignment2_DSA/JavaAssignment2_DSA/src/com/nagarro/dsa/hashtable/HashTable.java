package com.nagarro.dsa.hashtable;


public class HashTable {
	private Entry arr[];
	int arrsize;
	int size;

	public class Entry {

		private String key;
		private int value;

		public Entry(String key, int value) {
			this.key = key;
			this.value = value;
		}

		public String getKey() {
			return key;
		}

		public void setKey(String key) {
			this.key = key;
		}

		public int getValue() {
			return value;
		}

		public void setValue(int value) {
			this.value = value;
		}

	}

	public HashTable(int arrsize) {
		this.arrsize = arrsize;
		arr = new Entry[this.arrsize];
	}

	private int generateindex(String key) {
		return key.hashCode() % arrsize;
	}

	public void insert(String key, int value) {
		Entry new_entry = new Entry(key, value);

		arr[generateindex(key)] = new_entry;

		size++;
	}

	public boolean isContainKey(String key) {
		Entry entry = arr[generateindex(key)];
		if (entry != null)
			if (entry.getKey() == key)
				return true;
		return false;
	}

	public String toString() {
		String str = "{";
		for (Entry entry : arr) {
			if (entry != null) {
				str = str.concat("" + entry.key + "=" + entry.value + ", ");
			}
		}
		return str + "}";
	}

	public boolean delete(String key) {

		Entry entry = arr[generateindex(key)];

		if (entry != null)
			if (entry.getKey() != key || key == null) {
				return false;
			} else {
				arr[generateindex(key)] = null;
				--size;
				return true;
			}
		return false;
	}

	public Integer getValuebyKey(String key) {
		Entry entry = arr[generateindex(key)];

		if (entry != null)
			if (entry.getKey() == key)
				return entry.value;
		return null;

	}

	public int size() {
		return size;
	}
	


}
