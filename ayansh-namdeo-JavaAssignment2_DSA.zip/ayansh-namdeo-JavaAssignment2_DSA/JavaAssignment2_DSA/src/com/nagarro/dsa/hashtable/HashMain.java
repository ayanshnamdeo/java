package com.nagarro.dsa.hashtable;
public class HashMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTable ht = new HashTable(8);

		ht.insert("100", 10);
		ht.insert("200", 11);
		ht.insert("300", 12);
		ht.insert("400", 13);
		ht.insert("500", 14);

		System.out.println(ht);

		System.out.println("size:" + ht.size);

		System.out.println(ht.getValuebyKey("500"));

		System.out.println(ht.delete("300"));

		System.out.println(ht);

		System.out.println(ht.getValuebyKey("300"));

		System.out.println("size:" + ht.size);

		System.out.println(ht.isContainKey("500"));


	}
	}


