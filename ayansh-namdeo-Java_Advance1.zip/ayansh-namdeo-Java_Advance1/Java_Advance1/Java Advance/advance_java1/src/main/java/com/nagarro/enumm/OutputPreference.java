package com.nagarro.enumm;

public enum OutputPreference {
 PRICE,RATING,BOTH;
}
