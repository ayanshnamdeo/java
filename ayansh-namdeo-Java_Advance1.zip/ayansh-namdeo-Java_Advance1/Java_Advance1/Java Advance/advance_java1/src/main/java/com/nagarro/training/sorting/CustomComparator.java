package com.nagarro.training.sorting;

import java.util.Comparator;

import com.nagarro.training.model.Tshirt;

public class CustomComparator implements Comparator<Tshirt> {

	private String sortWith;

	public CustomComparator(String sortWith) {
		this.sortWith = sortWith;
	}

	public int compare(Tshirt t1, Tshirt t2) {
		int c = 0;
		 if (sortWith.equalsIgnoreCase("rating"))
	            return t2.getTshirtRating().compareTo(t1.getTshirtRating());//more rating first desc
	        else if (sortWith.equalsIgnoreCase("price"))
	            return t1.getTshirtPrice().compareTo(t2.getTshirtPrice());//less price first asc
	        else if (sortWith.equalsIgnoreCase("both")) {
	            c = t2.getTshirtRating().compareTo(t1.getTshirtRating());//desc 1.
	            if (c != 0) {
	                return c;
	            }
	            return t1.getTshirtPrice().compareTo(t2.getTshirtPrice());//asc 2.
	        }
		return c;

	}

}
