package com.nagarro.training.thread;

import java.io.File;

import com.nagarro.training.TshirtSearchApplication;

public class LoadAllCSVFiles implements Runnable {

	public void run() {
		TshirtSearchApplication.files = new File("src\\main\\resources\\csv_files").listFiles();
	}
	
}
