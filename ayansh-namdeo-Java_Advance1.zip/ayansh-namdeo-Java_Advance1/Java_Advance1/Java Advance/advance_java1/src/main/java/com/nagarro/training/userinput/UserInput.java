
package com.nagarro.training.userinput;

import java.util.Scanner;

import com.nagarro.enumm.*;




public class UserInput {
	


	private String tshirtColor;
	private String tshirtSize;
	private String tshirtGender;
	private String tshirtPreference;
	

	
	public UserInput(Scanner sc) {
		
		
			System.out.print("Enter Tshirt Color (available: Black,White,Blue,Purple,Grey,Pink,Maroon,lime,Yellow)-> ");
		
			boolean isValid = true;
			try {
				this.tshirtColor = sc.next();
			//	System.out.println(Color.valueOf(colorType.toUpperCase()));
				if(Color.valueOf(tshirtColor.toUpperCase())!=null)
					isValid = false;
				
			}
			catch(IllegalArgumentException e) {
				System.out.println("Enter a valid color of Tshirt:\n(available: Black,White,Blue,Purple,Grey,Pink,Maroon,Yellow)");
				this.tshirtColor = sc.next();
			}
			
			
			System.out.print("Enter Tshirt Size (choose: S , M , L, XL ) -> ");
			try {
				this.tshirtSize = sc.next();
				if(Size.valueOf(tshirtSize.toUpperCase())!=null)
					isValid = false;
				
			}
			catch(IllegalArgumentException e) {
				System.out.println("Enter a valid size of Tshirt:\n(choose: S , M , L, XL )");
				this.tshirtSize = sc.next();
			} 
			
	
			System.out.print("Enter Tshirt Gender(choose: M-male,F-female,U-unisex )-> ");
			
			try {
				this.tshirtGender = sc.next();
				if(Gender.valueOf(tshirtGender.toUpperCase())!=null)
					isValid = false;
				
			}
			catch(IllegalArgumentException e) {
				System.out.println("Enter a valid Gender:\n(M-male , F-femle,U-unisex )");
				this.tshirtGender = sc.next();
		}
			
			
			System.out.print("Enter Tshirt Preference (choose: Price ,Rating ,Both)-> ");
			
			try {
				this.tshirtPreference = sc.next();
				if(OutputPreference.valueOf(tshirtPreference.toUpperCase())!=null)
					isValid = false;
				
			}
			catch(IllegalArgumentException e) {
				System.out.println("Enter a valid output preference:");
				this.tshirtPreference = sc.next();
		}
			
		}
			

	public String getTshirtColor() {
		return tshirtColor;
	}

	public String getTshirtSize() {
		return tshirtSize;
	}

	public String getTshirtGender() {
		return tshirtGender;
	}

	public String getTshirtPreference() {
		return tshirtPreference;
	}

	

}


