package com.nagarro.enumm;

public enum Gender {
	M,F,U;
}
