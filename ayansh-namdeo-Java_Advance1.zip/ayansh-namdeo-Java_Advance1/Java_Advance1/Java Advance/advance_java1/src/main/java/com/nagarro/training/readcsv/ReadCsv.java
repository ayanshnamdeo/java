package com.nagarro.training.readcsv;

import java.io.*;

import com.nagarro.training.model.*;
import com.nagarro.training.sorting.CustomComparator;
import com.nagarro.training.userinput.UserInput;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import java.util.*;

public class ReadCsv {

	private UserInput userInput;
	private List<Tshirt> list;
	private CSVReader reader;
	private String[] nextLine;
	private String inputFormat;
	private String outputFormat;
	private Tshirt tshirt;
	private String sortWith;

	public ReadCsv(UserInput userInput) {
		this.userInput = userInput;
		this.list = new ArrayList<Tshirt>();
		this.inputFormat = inputFormat.format("%s,%s,%s", userInput.getTshirtColor(), userInput.getTshirtGender(),
				userInput.getTshirtSize());
		this.sortWith = userInput.getTshirtPreference();
	}

	public List<Tshirt> getAllMatchedTshirt(File[] file) {

		try {
			for (File loadedFiles : file) {
				reader = new CSVReaderBuilder(new FileReader(loadedFiles)).withSkipLines(1).build();

				while ((nextLine = reader.readNext()) != null) {

					this.outputFormat = outputFormat.format("%s,%s,%s", nextLine[2], nextLine[3], nextLine[4]);

					if (this.inputFormat.equalsIgnoreCase(this.outputFormat)) {
						this.tshirt = new Tshirt(nextLine[0], nextLine[1], nextLine[2], nextLine[3],
								Double.parseDouble(nextLine[5]), nextLine[4], Double.parseDouble(nextLine[6]),
								nextLine[7]);
						list.add(tshirt);
					}


				}

			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		Collections.sort(list, new CustomComparator(this.sortWith));
		return this.list;
	}
}
