package com.nagarro.training;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.nagarro.training.model.*;
import com.nagarro.training.readcsv.*;
import com.nagarro.training.thread.LoadAllCSVFiles;
import com.nagarro.training.userinput.UserInput;

public class TshirtSearchApplication {
	
	public static File[] files;
	
	public static void main(String[] args) throws InterruptedException {
		
		Thread myThread = new Thread(new LoadAllCSVFiles());

        ScheduledExecutorService service = Executors.newScheduledThreadPool(10);

        service.scheduleAtFixedRate(myThread, 0, 8, TimeUnit.SECONDS);
													
		UserInput userInput =new UserInput(new Scanner(System.in)); // take the user input from other class
		
		ReadCsv readCsv = new ReadCsv(userInput);
		
		List<Tshirt> matchedTshirt = readCsv.getAllMatchedTshirt(files);
		
		if(matchedTshirt.isEmpty()) {
			System.err.println("No matched tshirt found ...");
		}else {
			Iterator<Tshirt> iterator = matchedTshirt.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		}
		
	}

}
