package com.nagarro.enumm;

public enum Color {
	BLACK,WHITE,BLUE,PURPLE,GREY,PINK,MAROON,LIME,YELLOW;

}
