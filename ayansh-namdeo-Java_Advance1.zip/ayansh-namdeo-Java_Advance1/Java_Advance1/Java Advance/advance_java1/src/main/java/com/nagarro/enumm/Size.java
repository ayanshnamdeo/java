package com.nagarro.enumm;

public enum Size {
	 S,M,L,XL;
}
