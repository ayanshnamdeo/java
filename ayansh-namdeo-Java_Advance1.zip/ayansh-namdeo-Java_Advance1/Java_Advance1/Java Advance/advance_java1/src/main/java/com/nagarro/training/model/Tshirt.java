package com.nagarro.training.model;

public class Tshirt {

	private String tshirtId;
	private String tshirtName;
	private String tshirtColor;
	private String tshirtGender;
	private Double tshirtPrice;
	private String tshirtSize;
	private Double tshirtRating;
	private String tshirtAvailability;
	private String sortingWith;

	public Tshirt(String tshirtId, String tshirtName, String tshirtColor, String tshirtGender, double tshirtPrice,
			String tshirtSize, double tshirtRating, String tshirtAvail) {
		super();
		this.tshirtId = tshirtId;
		this.tshirtName = tshirtName;
		this.tshirtColor = tshirtColor;
		this.tshirtGender = tshirtGender;
		this.tshirtPrice = tshirtPrice;
		this.tshirtSize = tshirtSize;
		this.tshirtRating = tshirtRating;
		this.tshirtAvailability = tshirtAvail;
	}
	

	public String getTshirtId() {
		return tshirtId;
	}



	public void setTshirtId(String tshirtId) {
		this.tshirtId = tshirtId;
	}



	public String getTshirtName() {
		return tshirtName;
	}



	public void setTshirtName(String tshirtName) {
		this.tshirtName = tshirtName;
	}



	public String getTshirtColor() {
		return tshirtColor;
	}



	public void setTshirtColor(String tshirtColor) {
		this.tshirtColor = tshirtColor;
	}



	public String getTshirtGender() {
		return tshirtGender;
	}



	public void setTshirtGender(String tshirtGender) {
		this.tshirtGender = tshirtGender;
	}



	public Double getTshirtPrice() {
		return tshirtPrice;
	}



	public void setTshirtPrice(Double tshirtPrice) {
		this.tshirtPrice = tshirtPrice;
	}



	public String getTshirtSize() {
		return tshirtSize;
	}



	public void setTshirtSize(String tshirtSize) {
		this.tshirtSize = tshirtSize;
	}



	public Double getTshirtRating() {
		return tshirtRating;
	}



	public void setTshirtRating(Double tshirtRating) {
		this.tshirtRating = tshirtRating;
	}



	public String getTshirtAvailability() {
		return tshirtAvailability;
	}



	public void setTshirtAvailability(String tshirtAvailability) {
		this.tshirtAvailability = tshirtAvailability;
	}



	@Override
	public String toString() {
		
		System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		return "[tshirtId=" + tshirtId + ", tshirtName=" + tshirtName + ", tshirtColor=" + tshirtColor
				+ ", tshirtGender= " + tshirtGender + ", tshirtPrice=" + tshirtPrice + ", tshirtSize=" + tshirtSize
				+ ", tshirtRating=" + tshirtRating + ", tshirtAvailability=" + tshirtAvailability + "]";
		
	}
	
}
