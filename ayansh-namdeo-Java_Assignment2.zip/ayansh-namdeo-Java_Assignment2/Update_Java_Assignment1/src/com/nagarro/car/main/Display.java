package com.nagarro.car.main;
import java.util.*;
import com.nagarro.car.calculateinsurance.*;
import com.nagarro.car.details.*;

public class Display {
	static boolean flag=true;
	static boolean cat=true;
	//static boolean dog=true;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			do{
			
				Scanner sc= new Scanner(System.in);
				CarDetails carDetail=new CarDetails();
				CarInsurance insurance=new CarInsurance();
				
				System.out.print("enter model of car: ");
				carDetail.setModel(sc.nextLine());
				
				Set<String> s =new HashSet<>();
				s.add("SUV");
				s.add("HATCHBACK");
				s.add("SEDAN");
				do {
					System.out.print("enter the type of car(Accepted value => Hatchback || Sedan || SUV||): ");	
	                    String str=sc.nextLine();
	                    if(s.contains(str.toUpperCase())) {
	                		carDetail.setType(str);
	                        cat=false;
	                    }
	                    else {
	                        System.out.println("Wrong input");
	                        cat=true;
	                    }

	            }while(cat);
				
				
				
				
				
				System.out.print("enter price of the "+carDetail.getType()+"("+ carDetail.getModel() +"):");
				carDetail.setPrice(sc.nextInt());
				
					
				
				
				Set<String> sr =new HashSet<>();
				sr.add("BASIC");
				sr.add("PREMIUM");
				
				do {
					System.out.print("enter type of Insurance(Accepted value:Basic,Premium): ");	
	                    String sttr=sc.next();
	                    if(sr.contains(sttr.toUpperCase())) {
	                		insurance.setInsuranceType(sttr);
	                        cat=false;
	                    }
	                    else {
	                        System.out.println("Wrong input");
	                        cat=true;
	                    }

	            }while(cat);
				
				
				//System.out.print("enter type of Insurance(Accepted value:Basic,Premium): ");
					
					//insurance.setInsuranceType(sc.next());
					
	                
				
			
				
				double value = insurance.calculateInsurance(carDetail);
			
				
				System.out.println("Details are:-");
				System.out.println("-------------------------------------------------------");
				System.out.println("|car model is ->| " +carDetail.getModel() +"|");
				System.out.println("|car Price is ->| " +carDetail.getPrice() +"|");
				/*if(value >= 100000) {
				System.out.println("|car insurance value to be paid is -> | "+ value +" rs" +"|");
				}
				else {
					System.out.println("Please Enter Valid Input Price ,Greater than 100000");
				}*/
				System.out.println("|car insurance value to be paid is -> | "+ value +" rs" +"|");
				sc.nextLine();
				System.out.println("-------------------------------------------------------");
				System.out.print("|do you want to next y/n :|");
				char c=sc.nextLine().charAt(0);
				if(c=='y') {
					flag=true;
				}
				else
				{
					flag=false;
					System.out.println("-------------------------------------------------------");
					System.out.println("Thank you");
				}
			}while(flag);
	}
}

			
			

		



