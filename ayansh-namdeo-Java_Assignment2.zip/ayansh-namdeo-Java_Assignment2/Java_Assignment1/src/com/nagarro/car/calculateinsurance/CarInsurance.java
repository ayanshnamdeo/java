package com.nagarro.car.calculateinsurance;

import com.nagarro.exception.*;
import com.nagarro.car.details.*;

public class CarInsurance {

	String insuranceType;
	//double totalInsurance;
	
	public String getInsuranceType() {
		return insuranceType;
	}
	
	public void setInsuranceType(String insuranceType) {
		this.insuranceType=insuranceType;
	}
	
	public double calculateInsurance(CarDetails car) {
		double percentage=checkType(car.getType());
		double basic = percentage*car.getPrice();
		double premium=checkPremium(insuranceType,basic);
		return basic+premium;
		}
	
	public double checkType(String carType) {
		if(carType.equalsIgnoreCase("Hatchback"))
			return 0.05;
		else if(carType.equalsIgnoreCase("Sedan"))
			return 0.08;
		else if(carType.equalsIgnoreCase("SUV"))
			return 0.1;
		else
			throw new InvalidException("Invalid input");
	}
	
	public double checkPremium(String type,double basic) {
		if(type.equalsIgnoreCase("basic"))
			return 0;
		else
			if(type.equalsIgnoreCase("premium"))
				return 0.2*basic;
			else
				throw new InvalidException("wrong input");
	}

}

