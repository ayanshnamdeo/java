package com.nagarro.car.details;


public class CarDetails {
	String model;
	String type;
	int price;


public CarDetails() {
	}

//public CarDetails(String model,String type,int price) {
	//this.model=model;
	//this.type=type;
	//this.price=price;
//}

public String getModel() {
	return model;
}
public void setModel(String model)
{
	this.model=model;
}

public String getType() {
	return type;
}
public void setType(String type)
{
	this.type=type;
}

public int getPrice() {
	return price;
}
public void setPrice(int price)
{
	this.price=price;
}
}
