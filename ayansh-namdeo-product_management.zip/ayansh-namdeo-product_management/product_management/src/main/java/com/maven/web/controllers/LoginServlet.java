package com.maven.web.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.maven.web.dao.AdminDao;
import com.maven.web.entities.Admin;
import com.maven.web.helper.CreateSesssionFactory;
import com.maven.web.helper.DisplayMessageToJSP;
import com.maven.web.helper.EncryptPasswordWithMD;

@SuppressWarnings("serial")
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// play with response object
		// set content type
		response.setContentType("text/html");

		// get PrintWriter Object to write anything on jsp's
		PrintWriter out = response.getWriter();

		// play with request object
		// get email id using getParameter method and the html attribute name = "email"
		// or "password"
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		System.out.println(email+password);

		// Create AdminDao object to check Admin credential is valid or not...
		AdminDao adminDao = new AdminDao();

		// check if that admin present or not
		Admin currentAdmin = adminDao.checkAdminIsPresent(new Admin(email, password));

		if (currentAdmin != null) {
			HttpSession session = request.getSession();
			session.setAttribute("currentAdmin", currentAdmin);
			response.sendRedirect("admin-home.jsp");
		} else {
			DisplayMessageToJSP message = new DisplayMessageToJSP("Invalid Admin Credential ! try with another",
					"error", "alert-danger");
			HttpSession session = request.getSession();
			session.setAttribute("message", message);
			response.sendRedirect("admin-login.jsp");
		}

	}

}
