package com.maven.web.exception;

public class IllegalArgumentException extends RuntimeException {
	String message;

	public IllegalArgumentException(String message) {
		this.message = message;
	}

	public String toString() {
		return "IllegalArgumentException exception raised at line " + this.getStackTrace()[1].getLineNumber()
				+ " and at line " + this.getStackTrace()[0].getLineNumber() + " : '" + message + "'";
	}
}
