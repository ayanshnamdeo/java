package com.maven.web.controllers;

import java.io.FileInputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.maven.web.dao.AdminDao;

/**
 * Servlet implementation class SaveProductImage
 */
@MultipartConfig
@WebServlet("/updateImage")
public class SaveProductImage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Part image = request.getPart("editimage");
		String id = request.getParameter("id");
		
		System.err.println(image.getSubmittedFileName()+" "+id);
		
		AdminDao dao = new AdminDao();
		
		FileInputStream fis = (FileInputStream) image.getInputStream();
		
		dao.updateImageToDB(fis.readAllBytes(), Integer.parseInt(id), fis.getChannel().size());

	}

}
