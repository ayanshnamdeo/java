package com.maven.web.helper;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.maven.web.exception.IllegalArgumentException;

public class EncryptPasswordWithMD {

	public static String getPasswordEncrypted(char[] password) {

		try {

			MessageDigest md = MessageDigest.getInstance("MD5");

			// digest() method is called to calculate message digest
			// of an password input digest() return array of byte
			byte[] messageDigest = md.digest(new String(password).getBytes());

			// Convert byte array into signum representation
			BigInteger no = new BigInteger(1, messageDigest);

			// Convert message digest into hex value
			String hashtext = no.toString(16);
			while (hashtext.length() < 32) {
				hashtext = "0" + hashtext;
			}
			return hashtext;

		}

		// For specifying wrong message digest algorithms
		catch (NoSuchAlgorithmException e) {
			throw new IllegalArgumentException("no such message digest algo is present ...");
		}

	}

}
