package com.maven.web.entities;

import java.util.Arrays;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product {

	@Id
	@GeneratedValue
//	@GenericGenerator(name = "product_generator", strategy = "uuid")
//	@GeneratedValue
	@Column(name = "product_id")
	private Integer productId;

	@Column(name = "item_title", nullable = false)
	private String itemTitle;

	@Column(name = "item_quantity", nullable = false)
	private String itemQuantity;
	
	@Column(name = "item_image_size", nullable = false)
	private long itemImageSize;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", itemTitle=" + itemTitle + ", itemQuantity=" + itemQuantity
				+ ", itemSize=" + itemSize + ", itemImage=" + Arrays.toString(itemImage) + "]";
	}

	public Product(String itemTitle, String itemQuantity, String itemSize, byte[] itemImage, long itemImageSize) {
		super();
		this.itemTitle = itemTitle;
		this.itemQuantity = itemQuantity;
		this.itemSize = itemSize;
		this.itemImage = itemImage;
		this.itemImageSize = itemImageSize;
	}

	/**
	 * @return the itemImageSize
	 */
	public long getItemImageSize() {
		return itemImageSize;
	}

	/**
	 * @param itemImageSize the itemImageSize to set
	 */
	public void setItemImageSize(long itemImageSize) {
		this.itemImageSize = itemImageSize;
	}

	public Product() {
		super();
	}

	@Column(name = "item_size", nullable = false)
	private String itemSize;

	@Lob
	@Column(name = "item_image", nullable = false, columnDefinition = "blob")
	private byte[] itemImage;

//	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE, CascadeType.DETACH, CascadeType.REFRESH })
//	@JoinColumn(name = "email")
//	private Admin admin;

	/**
	 * @return the productId
	 */
	public Integer getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	/**
	 * @return the itemTitle
	 */
	public String getItemTitle() {
		return itemTitle;
	}

	/**
	 * @param itemTitle the itemTitle to set
	 */
	public void setItemTitle(String itemTitle) {
		this.itemTitle = itemTitle;
	}

	/**
	 * @return the itemQuantity
	 */
	public String getItemQuantity() {
		return itemQuantity;
	}

	/**
	 * @param itemQuantity the itemQuantity to set
	 */
	public void setItemQuantity(String itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	/**
	 * @return the itemSize
	 */
	public String getItemSize() {
		return itemSize;
	}

	/**
	 * @param itemSize the itemSize to set
	 */
	public void setItemSize(String itemSize) {
		this.itemSize = itemSize;
	}

	/**
	 * @return the itemImage
	 */
	public byte[] getItemImage() {
		return itemImage;
	}

	/**
	 * @param itemImage the itemImage to set
	 */
	public void setItemImage(byte[] itemImage) {
		this.itemImage = itemImage;
	}

}
