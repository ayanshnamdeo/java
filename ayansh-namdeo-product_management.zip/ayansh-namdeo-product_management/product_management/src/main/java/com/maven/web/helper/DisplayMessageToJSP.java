package com.maven.web.helper;

public class DisplayMessageToJSP {

	private String messageDetails;
	private String messageType;
	private String cssClass;

	public DisplayMessageToJSP(String messageDetails, String messageType, String cssClass) {
		super();
		this.messageDetails = messageDetails;
		this.messageType = messageType;
		this.cssClass = cssClass;
	}

	/**
	 * @return the messageDetails
	 */
	public String getMessageDetails() {
		return messageDetails;
	}

	/**
	 * @param messageDetails the messageDetails to set
	 */
	public void setMessageDetails(String messageDetails) {
		this.messageDetails = messageDetails;
	}

	/**
	 * @return the messageType
	 */
	public String getMessageType() {
		return messageType;
	}

	/**
	 * @param messageType the messageType to set
	 */
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	/**
	 * @return the cssClass
	 */
	public String getCssClass() {
		return cssClass;
	}

	/**
	 * @param cssClass the cssClass to set
	 */
	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}

}
