package com.maven.web.helper;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.maven.web.entities.Admin;
import com.maven.web.entities.Product;

public class CreateSesssionFactory {

	private CreateSesssionFactory() {

	}

	public static final SessionFactory GET_FACTORY = new Configuration()
			.configure("hibernate.cfg.xml").addAnnotatedClass(Admin.class)
			.addAnnotatedClass(Product.class).buildSessionFactory();
	
	
	public static final Session SESSION = GET_FACTORY.openSession(); 
}
