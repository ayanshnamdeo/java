package com.maven.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.maven.web.entities.Admin;
import com.maven.web.entities.Product;
import com.maven.web.helper.EncryptPasswordWithMD;

public class Main {

	public static void main(String[] args) throws IOException {

		SessionFactory factory = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(Admin.class)
				.addAnnotatedClass(Product.class).buildSessionFactory();
		
		Admin admin = new Admin("user@g.com",EncryptPasswordWithMD.getPasswordEncrypted(new String("Pass123").toCharArray()));

		Session session = factory.getCurrentSession();

		Transaction t = session.beginTransaction();

		session.saveOrUpdate(admin);
		

		t.commit();
	}

}
