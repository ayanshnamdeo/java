package com.maven.web.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.maven.web.entities.Admin;
import com.maven.web.entities.Product;
import com.maven.web.exception.AdminNotExistException;
import com.maven.web.helper.CreateSesssionFactory;
import com.maven.web.helper.EncryptPasswordWithMD;

public class AdminDao {

	private Session session;

	public AdminDao() {
		this.session = CreateSesssionFactory.SESSION;
	}

	public Admin checkAdminIsPresent(Admin admin) {

		Admin returnValidAdmin = null;

		// get md5 hash form of login password which will check with existing password
		// if user is present...
		String passwordToMatch = EncryptPasswordWithMD.getPasswordEncrypted(admin.getPassword().toCharArray());
		String existingPassword = "";

		try {

			// start the transaction
			Transaction transaction = session.beginTransaction();

			// get admin for that particular id
			Admin presentAdmin = session.get(Admin.class, admin.getEmail());

			// check if admin is not present then throw our customized exception
			// AdminNotExistException....
			if (presentAdmin == null)
				throw new AdminNotExistException("no admin exist with this email '" + admin.getEmail() + "'");
			else {
				// get md5 hash form of existing admin password
				existingPassword = presentAdmin.getPassword();
				
				System.out.println(existingPassword+" "+passwordToMatch);

				// here we chech if user is present is it password correct or not...
				if (existingPassword.compareTo(passwordToMatch) == 0)
					returnValidAdmin = presentAdmin;

			}

			// commit the transaction
			transaction.commit();

		} catch (AdminNotExistException ex) {
			System.out.println(ex); // print the exception to the console
		}

		return returnValidAdmin;

	}

	public boolean addProduct(Product product, Admin admin) {

		try {

			List<Product> list = new ArrayList<Product>();

			list = admin.getProduct();

			list.add(product);

			Transaction t = session.beginTransaction();

			admin.setProduct(list);

			session.saveOrUpdate(admin);

			t.commit();

			return true;

		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(ex);
			return false;
		}

	}

	public boolean updateProduct(String id, String title, String quantity, String size) {

		try {
			Transaction t = session.beginTransaction();

			session.createQuery("update Product set item_title = '" + title + "', item_size = '" + size
					+ "', item_quantity = '" + quantity + "' where product_id = '" + id + "'").executeUpdate();

			t.commit();

			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	
	public boolean updateImageToDB(byte[] image, int productId, long imageSize) {
		
		try {
			session = CreateSesssionFactory.GET_FACTORY.openSession();
			session.beginTransaction();
			
			Product product = session.get(Product.class, productId);
			
			product.setItemImage(image);
			
			product.setItemImageSize(imageSize);
			
			session.getTransaction().commit();
//			
//			
//			product.setItemImage(image);
			
			return true;
		}catch(Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}

}
