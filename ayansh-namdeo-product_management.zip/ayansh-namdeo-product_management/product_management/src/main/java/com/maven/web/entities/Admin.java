package com.maven.web.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admin {

	public Admin(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Admin [email=" + email + ", password=" + password + ", products=" + products + "]";
	}

	@Id
	@Column(name = "email")
	private String email;

	@Column(name = "password", nullable = false)
	private String password;
	/**
	 * cascade type persist : if the entity is saved / related entity will also be
	 * persisted remove : if the entity is removed / " " refresh : if the entity is
	 * refresh / " " detach : " " merge : " " all : combination of all of the above
	 * cascade type together
	 * 
	 */
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)	
	@JoinColumn(name = "email_id", referencedColumnName = "email")
	private List<Product> products = new ArrayList<Product>();

	public Admin() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the product
	 */
	public List<Product> getProduct() {
		return products;
	}

	/**
	 * @param product the product to set
	 */
	public void setProduct(List<Product> product) {
		this.products = product;
	}

//	public void add(Product tempProducts) {
//		
//		if(products == null) {
//			products = new ArrayList<Product>();
//		}
//		
//		products.add(tempProducts);
//		
//		tempProducts.setProduct(this);
//		
//	}
}
