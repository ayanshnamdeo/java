package com.maven.web.controllers;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.maven.web.dao.AdminDao;
import com.maven.web.entities.Admin;
import com.maven.web.entities.Product;
import com.maven.web.helper.CreateSesssionFactory;

/**
 * Servlet implementation class AddProductInfo
 */
@MultipartConfig
public class AddProductInfo extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();

		String title = request.getParameter("title");
		String quantity = request.getParameter("quantity");
		String size = request.getParameter("size");
		Part image = request.getPart("image");
		
		

		FileInputStream fis = (FileInputStream) image.getInputStream();
		
		System.out.println(fis.getChannel().size());

		Product product = new Product(title, quantity, size, image.getInputStream().readAllBytes(), fis.getChannel().size());

		AdminDao dao = new AdminDao();

		HttpSession session = request.getSession();

		Admin admin = (Admin) session.getAttribute("currentAdmin");

		boolean isSave = dao.addProduct(product, admin);

		if (isSave)
			out.println("done");
		else
			out.println("not done");

	}

}
