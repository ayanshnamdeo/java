package com.nagarro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvanceJava5RestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
