package com.nagarro.services;import com.nagarro.dao.AuthorDao;
import com.nagarro.dao.BookDao;
import com.nagarro.dao.UserDao;
import com.nagarro.entity.Author;
import com.nagarro.entity.Book;
import com.nagarro.entity.User;
import com.nagarro.service.impl.AuthorServiceImpl;
import com.nagarro.service.impl.BookServiceImpl;
import com.nagarro.service.impl.UserServiceImpl;
import com.nagarro.services.BookService;
import com.nagarro.services.UserService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

public class ServiceTests {

    @Mock
    private BookDao bookDao;

    @Mock
    private UserDao userDao;
    
    @Mock
    private AuthorDao authorDao;
    
    @InjectMocks
    private AuthorServiceImpl authorService;

    @InjectMocks
    private BookServiceImpl bookService;

    @InjectMocks
    private UserServiceImpl userService;
    
    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testAuthorService() {
        // Mock data
        Author author = new Author();
        author.setId(1);
        author.setName("Jane Doe");
        
        assertNotNull(authorDao, "authorDao is null");

        when(authorDao.findAll()).thenReturn(List.of(author));
        when(authorDao.getOne(1)).thenReturn(author);

        // Test the service methods
        List<Author> authors = authorService.authors();
        Author retrievedAuthor = authorService.addAuthor(author);

        // Validate the results
        assertNotNull(authors);
        assertEquals(1, authors.size());
      //  assertEquals("Spring Boot Basics", books.get(0).getName());

        assertNotNull(retrievedAuthor);
       // assertEquals("Jane Doe", retrievedBook.getAuthor());

        // Verify that the DAO methods were called
        verify(authorDao, times(1)).findAll();
        System.out.println("op"+retrievedAuthor);
//        verify(authorDao, times(1)).getOne(1);
    }
    
    
  

    @Test
    public void testBookService() {
        // Mock data
        Book book = new Book();
        book.setBookCode(101);
        book.setAuthor("Jane Doe");
        book.setName("Spring Boot Basics");
        
        assertNotNull(bookDao, "bookDao is null");

        when(bookDao.findAll()).thenReturn(List.of(book));
        when(bookDao.getOne(101)).thenReturn(book);

        // Test the service methods
        List<Book> books = bookService.getBooks();
        Book retrievedBook = bookService.getBook(101);

        // Validate the results
        assertNotNull(books);
        assertEquals(1, books.size());
        assertEquals("Spring Boot Basics", books.get(0).getName());

        assertNotNull(retrievedBook);
        assertEquals("Jane Doe", retrievedBook.getAuthor());
        
        System.out.println("op"+retrievedBook);

        // Verify that the DAO methods were called
        verify(bookDao, times(1)).findAll();
        verify(bookDao, times(1)).getOne(101);
    }

    @Test
    public void testUserService() {
        // Mock data
    	User user = new User();
        user.setId(1);
        user.setUserName("john_doe");
        user.setPassword("password123");
        User user1=new User();
        user1.setId(2);
        user1.setUserName("mike_doe");
        user1.setPassword("password321");

        // Ensure that userDao is not null
        assertNotNull(userDao, "userDao is null");

        // Mock the behavior of userDao
        when(userDao.findbyUserName("john_doe")).thenReturn(user);
        when(userDao.findbyUserName("mike_doe")).thenReturn(user1);
        // Ensure that userService is not null
        assertNotNull(userService, "userService is null");

        // Test the service method
        User retrievedUser = userService.getUser("john_doe");
        User retrievedUser1 = userService.getUser("mike_doe");
        // Validate the result
        assertNotNull(retrievedUser, "retrievedUser is null");
        assertNotNull(retrievedUser1, "retrievedUser is null");
        assertEquals("password123", retrievedUser.getPassword(), "Password mismatch");
        assertEquals("password321", retrievedUser1.getPassword(), "Password mismatch");
        // Verify that the DAO method was called
        verify(userDao, times(1)).findbyUserName("john_doe");
        verify(userDao, times(1)).findbyUserName("mike_doe");
        System.out.println("op"+retrievedUser);
        System.err.println("new user"+retrievedUser1);
    }
}
