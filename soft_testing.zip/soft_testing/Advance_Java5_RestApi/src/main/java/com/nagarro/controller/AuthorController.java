package com.nagarro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.entity.Author;
import com.nagarro.services.AuthorService;

@RestController
public class AuthorController {
	@Autowired
	AuthorService authorService;

	@GetMapping("/authors")
	public List<Author> getAuthors() {
		return this.authorService.authors();
	}

	@PostMapping(path = "/authors", consumes = "application/json")
	public Author addAuthor(@RequestBody Author author) {
		return authorService.addAuthor(author);

	}

	@DeleteMapping("/authors/{id}")
	public ResponseEntity<HttpStatus> deleteAuthor(@PathVariable int id) {
		try {
			this.authorService.delete(id);
			return new ResponseEntity<HttpStatus>(HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
