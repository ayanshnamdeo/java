package com.nagarro.services;

import org.springframework.stereotype.Service;

import com.nagarro.entity.User;

@Service
public interface UserService {
	public User getUser(String uname);

	public User addUser(User user);

	public void deleteUser(int id);

	public User updateUser(User user);
}
