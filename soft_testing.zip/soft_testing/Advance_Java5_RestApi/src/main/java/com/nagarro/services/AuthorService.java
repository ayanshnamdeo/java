package com.nagarro.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarro.entity.Author;

@Service
public interface AuthorService {
	public List<Author> authors();
	public Author addAuthor(Author author);
	public void delete(int id);
}
