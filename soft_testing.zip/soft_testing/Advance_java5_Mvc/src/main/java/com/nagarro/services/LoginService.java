package com.nagarro.services;

import org.springframework.stereotype.Service;

import com.nagarro.entity.User;

@Service
public interface LoginService {

	public User getLogin(String userName);
}
