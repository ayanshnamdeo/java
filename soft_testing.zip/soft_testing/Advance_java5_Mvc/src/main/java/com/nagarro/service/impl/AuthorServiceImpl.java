package com.nagarro.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.nagarro.entity.Author;
import com.nagarro.services.AuthorService;

@Component
public class AuthorServiceImpl implements AuthorService {
	@Autowired
	RestTemplate restTemplate;
	@Override
	public List<Author> getAuthors() {
		// TODO Auto-generated method stub
		String url="http://localhost:8082/authors";
		ResponseEntity<Author[]> response =
				  restTemplate.getForEntity(
				  url,
				  Author[].class);
		Author[] book=response.getBody();
		List<Author> result=new ArrayList<>();
		for(Author b:book) {
			System.out.println(b);
			result.add(b);
		}
		return result;
	}

}
