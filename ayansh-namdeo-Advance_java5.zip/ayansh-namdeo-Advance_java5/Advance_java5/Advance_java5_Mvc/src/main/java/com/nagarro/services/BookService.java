package com.nagarro.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarro.entity.Book;

@Service
public interface BookService {

	public Book addBook(Book book);
	public void edit(Book book);
	public void delete(int id);
	public List<Book> getAllBook();
}
