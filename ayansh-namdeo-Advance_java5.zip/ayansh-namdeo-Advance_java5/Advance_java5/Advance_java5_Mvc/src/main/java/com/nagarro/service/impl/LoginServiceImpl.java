package com.nagarro.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.nagarro.entity.User;
import com.nagarro.services.LoginService;

@Component
public class LoginServiceImpl implements LoginService {

	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public User getLogin(String userName) {
		// TODO Auto-generated method stub
		String url="http://localhost:8082/user/"+userName;
		
		return restTemplate.getForObject(url, User.class);
	}
}
