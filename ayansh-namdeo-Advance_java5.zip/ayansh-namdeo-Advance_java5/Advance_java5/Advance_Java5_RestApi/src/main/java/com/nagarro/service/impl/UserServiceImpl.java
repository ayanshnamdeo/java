package com.nagarro.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.nagarro.dao.UserDao;
import com.nagarro.entity.User;
import com.nagarro.services.UserService;

@Component
public class UserServiceImpl  implements UserService{
	@Autowired
	UserDao userDao;

	@Override
	public User getUser(String uname) {
		// TODO Auto-generated method stub
		return userDao.findbyUserName(uname);
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.save(user);
	}

	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub
		User u=userDao.getOne(id);
		userDao.delete(u);
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return userDao.save(user);
	}
	
}
