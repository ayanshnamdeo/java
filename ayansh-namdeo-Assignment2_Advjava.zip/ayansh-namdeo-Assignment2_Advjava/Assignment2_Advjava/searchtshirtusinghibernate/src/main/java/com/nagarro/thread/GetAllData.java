package com.nagarro.thread;

import java.io.File;

import com.nagarro.searchtshirtusinghibernate.InsertDataToSql;

public class GetAllData implements Runnable {
	public void run() {
		// read all the csv files present inside res folder
		InsertDataToSql.files = new File("res\\csv").listFiles();

	}
}