package com.nagarro.input;


import org.hibernate.Session;
import com.nagarro.model.SearchTShirt;
import com.nagarro.Scan.Scan;

public class Input {

	String color;
	char gender;
	String size;
	String opPreference;
	Session session;

	public void takeInput(Session session) {
		this.session = session;
		inputColour();
		inputGender();
		inputSize();
		inputOpPrefrence();
	}

	public void inputColour() {
		System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		System.out.print("Enter Tshirt Color (available: Black,White,Blue,Purple,Grey,Pink,Maroon,Yellow)-> ");
		try {
			this.color = Scan.scan().next();
		} catch (Exception e) {
			System.err.println("Invalid Colour");
			inputColour();
		}
		
		
	}

	public void inputGender() {
		System.out.print("Enter Tshirt Gender(choose: M-male,F-female,U-unisex )-> ");
		try {
			this.gender = Scan.scan().next().trim().charAt(0);
		} catch (Exception e) {
			System.out.println("Invalid Gender");
			inputGender();
		}
	}

	public void inputSize() {
		System.out.print("Enter Tshirt Size (choose: S , M , L, XL ) -> ");
		try {
			this.size = Scan.scan().next().trim();
		} catch (Exception e) {
			System.err.println("Invalid Size");
			inputSize();
		}
	}

	public void inputOpPrefrence() {
		System.out.print("Enter Tshirt Preference (choose: Price ,Rating ,Both)-> ");

		try {
			this.opPreference = Scan.scan().next().trim();
		} catch (Exception e) {
			System.err.println("Invalid output prefrence");
			inputOpPrefrence();
		}
	}

	// This method will search and print the matched data
	public void showOp() {
		SearchTShirt tshirt = new SearchTShirt();
		tshirt.searchAndShowResult(color, gender, size, opPreference, session);
	}

}
