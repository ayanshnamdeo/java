package com.nagarro.searchtshirtusinghibernate;

import java.io.File;
import java.io.FileReader;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.nagarro.bean.TShirt;
import com.nagarro.thread.*;

public class InsertDataToSql {

	private String[] nextLine;
	private CSVReader reader;
	public static File[] files;

	/**
	 * This method will read the data from csv and store it in the mysql database
	 * using hibernate
	 * 
	 * @param session
	 * @throws InterruptedException
	 */
	public void insertData(Session session) throws InterruptedException {
		new Thread(new GetAllData()).start();// will load the 3 csv file data into single file
		Thread.sleep(100);
		if (files == null || files.length == 0) {
			System.out.println("no file found");
		}
		try {
			for (File file : files) {
				// reading data using opencsv 3rd party dependency
				reader = new CSVReaderBuilder(new FileReader(file)).withSkipLines(1).build();
				// traverse data inside the file
				while ((nextLine = reader.readNext()) != null) {

					Transaction tx = session.beginTransaction();// starting the transaction
					TShirt tshirt = new TShirt();
					tshirt.setId(nextLine[0]);
					tshirt.setName(nextLine[1]);
					tshirt.setColour(nextLine[2]);
					tshirt.setGenderRecommendation(nextLine[3].charAt(0));
					tshirt.setSize(nextLine[4]);
					tshirt.setPrice(Double.parseDouble(nextLine[5]));
					tshirt.setRating(Double.parseDouble(nextLine[6]));
					tshirt.setAvailability(nextLine[7].charAt(0));
					session.save(tshirt);// saving or update the obj in the mysql database
					tx.commit();// saving the transaction

				}
			}
			session.close();// after saving the transaction closing the session

		} catch (Exception e) {

		}

	}

}
