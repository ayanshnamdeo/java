package com.nagarro.model;


import java.util.ArrayList;
import java.util.List;

import com.nagarro.bean.TShirt;

import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.hibernate.Session;

public class SearchTShirt {

	/**
	 * This method will search the matching record using hql query and sort it and
	 * then print the data
	 * 
	 * @param colour
	 * @param gender
	 * @param size
	 * @param opPrefrence
	 * @param session
	 */
	public void searchAndShowResult(String colour, char gender, String size, String opPrefrence, Session session) {

		String qry = "";
		if (opPrefrence.equalsIgnoreCase("rating")) {
			qry = "from TShirt t where t.colour=:c and t.size=:s and t.genderRecommendation=:g order by t.rating desc";
		} else if (opPrefrence.equalsIgnoreCase("price")) {
			qry = "from TShirt t where t.colour=:c and t.size=:s and t.genderRecommendation=:g order by t.price asc";
		} else if (opPrefrence.equalsIgnoreCase("both")) {
			qry = "from TShirt t where t.colour=:c and t.size=:s and t.genderRecommendation=:g order by t.price asc,t.rating asc";
		} else {
			System.err.println("Enter a valid Output preference");
			System.exit(1);
		}
		Transaction tx = session.beginTransaction();
		Query q = session.createQuery(qry);
		q.setParameter("c", colour);
		q.setParameter("s", size);
		
		q.setParameter("g", gender);
		List<TShirt> list = q.list();//getting the list of matched data
		ArrayList<TShirt> matchedTShirt = new ArrayList();
		//if list is empty that means no records is there so exit
		if (list.size() == 0) {
			System.err.println("No Matched Item Found");
			System.exit(1);
		}

		for (TShirt tshirt : list) {
			matchedTShirt.add(tshirt);// storing tshirt in arraylist
			System.out.println(tshirt);// Will print the result using toString() method
			System.out.println("-------------------------------------------------------------------"
					+ "-------------------------------------------------------------------------------------------------");

		}
	}
}
