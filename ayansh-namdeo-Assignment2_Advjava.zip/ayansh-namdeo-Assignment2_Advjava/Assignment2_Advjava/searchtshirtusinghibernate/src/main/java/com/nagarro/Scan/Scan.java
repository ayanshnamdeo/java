package com.nagarro.Scan;
import java.util.Scanner;

public class Scan {
	/**
	 * 
	 * @return scanner obj
	 */
public static Scanner scan() {
	Scanner sc=new Scanner(System.in);
	return sc;
}
}
