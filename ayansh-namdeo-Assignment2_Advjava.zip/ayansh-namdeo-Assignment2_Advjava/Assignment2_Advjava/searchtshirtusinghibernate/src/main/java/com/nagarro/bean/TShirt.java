package com.nagarro.bean;


import javax.persistence.Id;

import javax.persistence.Entity;

@Entity // creating table TShirt in mysql using hibernate
public class TShirt {
	@Id
	private String id;// creating id as a primary key for the table TShirt
	
	private String name;
	private String colour;
	private char genderRecommendation;
	private String size;
	protected double price;
	protected double rating;
	private char availability;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the colour
	 */
	public String getColour() {
		return colour;
	}

	/**
	 * @param colour the colour to set
	 */
	public void setColour(String colour) {
		this.colour = colour;
	}

	/**
	 * @return the genderRecommendation
	 */
	public char getGenderRecommendation() {
		return genderRecommendation;
	}

	/**
	 * @param genderRecommendation the genderRecommendation to set
	 */
	public void setGenderRecommendation(char genderRecommendation) {
		this.genderRecommendation = genderRecommendation;
	}

	/**
	 * @return the size
	 */
	public String getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(String size) {
		this.size = size;
	}

	/**
	 * @return the price
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(double price) {
		this.price = price;
	}

	/**
	 * @return the rating
	 */
	public double getRating() {
		return rating;
	}

	/**
	 * @param rating the rating to set
	 */
	public void setRating(double rating) {
		this.rating = rating;
	}

	/**
	 * @return the availability
	 */
	public char getAvailability() {
		return availability;
	}

	/**
	 * @param availability the availability to set
	 */
	public void setAvailability(char availability) {
		this.availability = availability;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */

//whenever obj ref is printed toString() will call automatically
	@Override
	public String toString() {
		System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		return "Id:" + id + "\t Name:" + name + "\t Colour:" + colour + "\t GenderRecommendation:"
				+ genderRecommendation + "\t Size:" + size + "\t Price:" + price + "\t Rating:" + rating
				+ "\t Availability:" + availability;
	}

}