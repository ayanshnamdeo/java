package com.nagarro.searchtshirtusinghibernate;

import com.nagarro.bean.TShirt;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.nagarro.input.Input;

/**
 * This is the Main class which contain main method
 *
 */

public class App {

	public static void main(String[] args) throws Exception {
		// Configuring the hbm.cfg file
		Configuration cf = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(TShirt.class);
		// Create sessionfactory ref obj to open the session
		SessionFactory sf = cf.buildSessionFactory();
		Session session = sf.openSession();
		// Creating obj of class insertdatatoSql to insert data from csv to mysql
		InsertDataToSql insert = new InsertDataToSql();
		insert.insertData(session);
		Input inp = new Input();
		// This method will take input from the user
		inp.takeInput(session);
		// This method will show the respective output
		inp.showOp();
	}
}
