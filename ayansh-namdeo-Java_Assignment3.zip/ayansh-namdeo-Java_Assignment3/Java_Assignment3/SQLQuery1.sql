--1 query
select * from Sales.SalesPerson;

-- 2Select both the FirstName and LastName of records from the Person table where the FirstName begins with the letter �B�. 
--(Schema(s) involved: Person)

select FirstName,LastName from Person.Person where Firstname like'B%' ;


--3Select a list of FirstName and LastName for employees where Title is one of Design Engineer, Tool Designer or Marketing 
--Assistant. (Schema(s) involved: HumanResources, Person

select p.FirstName, p.LastName 
from Person.Person As p inner join HumanResources.Employee As e 
on p.BusinessEntityID=e.BusinessEntityID
where e.JobTitle= 'Design Engineer'or e.JobTitle='Tool Designer' or e.JobTitle='Marketing Assistant' ;


-- 4 Display the Name and Color of the Product with the maximum weight. (Schema(s) involved: Production)

SELECT top 1 Name, Color, Weight
FROM Production.Product
ORDER BY WEIGHT DESC;

--2nd way
select Name,Color,Weight from Production.Product where Weight=(select max(Weight) from Production.Product );

--5.Display Description and MaxQty fields from the SpecialOffer table. Some of the MaxQty values are NULL, in this case display 
--the value 0.00 instead. (Schema(s) involved: Sales)

select Description ,COALESCE(MaxQty,0.00) AS 'MAXIMUM Quantity' from Sales.SpecialOffer;

--2nd way
SELECT Description, ISNULL(MaxQty,0.00) AS MaximumQty
FROM Sales.SpecialOffer;

--6.Display the overall Average of the [CurrencyRate].[AverageRate] values for the exchange rate �USD� to �GBP� for the year 2005 
--i.e. FromCurrencyCode = �USD� and ToCurrencyCode = �GBP�. Note: The field [CurrencyRate].[AverageRate] is defined as 
--'Average exchange rate for the day.' (Schema(s) involved: Sales)

SELECT AVG(AverageRate) AS 'Average exchange rate for the day'
FROM Sales.CurrencyRate
WHERE FromCurrencyCode = 'USD' AND 
	  ToCurrencyCode = 'GBP';

--7.Display the FirstName and LastName of records from the Person table where FirstName contains the letters �ss�. Display an 
--additional column with sequential numbers for each row returned beginning at integer 1. (Schema(s) involved: Person)


SELECT ROW_NUMBER() OVER(Order BY FirstName) AS 'Sequence',
	FirstName,
	LastName
FROM Person.Person
WHERE FirstName LIKE '%ss%';



/* 8--Sales people receive various commission rates that belong to 1 of 4 bands. (Schema(s) involved: Sales)
CommissionPct Commission Band
0.00 Band 0
Up To 1% Band 1
MS �203: SQL
5
Up To 1.5% Band 2
Greater 1.5% Band 3
Display the [SalesPersonID] with an additional column entitled �Commission Band� indicating the appropriate band as above.*/

SELECT BusinessEntityID AS 'SalesPersonID',
	   CASE
			WHEN CommissionPct = 0.00 THEN 'BAND 0'
			WHEN CommissionPct > 0.00 AND CommissionPct <= 0.01 THEN 'BAND 1'
			WHEN CommissionPct > 0.01 AND CommissionPct <= 0.015 THEN 'BAND 2'
			WHEN CommissionPct > 0.015 THEN 'BAND 3'
	   END AS 'Commission Band'
FROM Sales.SalesPerson
ORDER BY [Commission Band];

--9_Display the managerial hierarchy from Ruth Ellerbrock (person type � EM) up to CEO Ken Sanchez. Hint: use 
--[uspGetEmployeeManagers] (Schema(s) involved: [Person], [HumanResources])


DECLARE @EmployeeID int=(select he.BusinessEntityID from HumanResources.Employee As he inner join Person.Person As pp 
on pp.BusinessEntityID=he.BusinessEntityID  where pp.FirstName='Ruth' and pp.LastName='Ellerbrock'and  pp.PersonType='em');
exec dbo.uspGetEmployeeManagers @BusinessEntityID = @EmployeeID;




--10.display the ProductId of the product with the largest stock level. Hint: Use the Scalar-valued function [dbo]. [UfnGetStock]. 
--(Schema(s) involved: Production)
select  Top 1 ProductID ,Quantity from Production.ProductInventory order by Quantity desc ;select pp.ProductID ,Quantity from Production.Product as pp inner join Production.ProductInventory as pi on(pp.ProductID=pi.ProductID) where Quantity=(select max(Quantity) from Production.ProductInventory);