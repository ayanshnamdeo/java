/*Write a trigger for the Product table to ensure the list price can never be raised more than 15 Percent in a single change. Modify the 
above trigger to execute its check code only if the ListPrice column is updated */

CREATE TRIGGER Production.updateLimitTrigger
ON Production.Product
FOR UPDATE AS 
	IF EXISTS 
		(SELECT * FROM inserted I 
		JOIN deleted D ON I.ProductID = D.ProductID
		WHERE I.ListPrice > (D.ListPrice * 1.15))
		
	BEGIN RAISERROR('Cannot increase the price for more than 15%.', 16, 1)
	ROLLBACK TRANSACTION
END;

GO
ALTER TRIGGER Production.updateLimitTrigger 
ON Production.Product 
FOR UPDATE AS IF UPDATE(ListPrice)
	IF EXISTS
		(SELECT * FROM inserted i 
		JOIN deleted D ON I.ProductID = D.ProductID
		WHERE I.ListPrice > (D.ListPrice * 1.15))

	BEGIN RAISERROR('Cannot increase the price for more than 15%.', 16, 1)
	ROLLBACK TRANSACTION
END;


