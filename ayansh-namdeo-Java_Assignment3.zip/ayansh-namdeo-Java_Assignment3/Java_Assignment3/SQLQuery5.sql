/*excercise 5
 
Write a Procedure supplying name information from the Person.Person table and accepting a filter for the first name. Alter the above 
Store Procedure to supply Default Values if user does not enter any value.*/

CREATE PROCEDURE firstNameFilter 
@name nvarchar(50)
AS 
BEGIN 
	IF (@name = '') 
	BEGIN 
		SELECT BusinessEntityID, FirstName, LastName FROM Person.Person ORDER BY FirstName; 
	END 
	ELSE BEGIN 
		SELECT  BusinessEntityID, FirstName, LastName FROM Person.Person where FirstName = @name ORDER BY FirstName; 
	END 
END 

GO 
DECLARE @FirstName nvarchar(50) 
SET @FirstName='' 
EXECUTE firstNameFilter @FirstName
SET @FirstName='Wayne' 
EXECUTE firstNameFilter @FirstName;


