
--Write separate queries using a join, a subquery, a CTE, and then an EXISTS to list all AdventureWorks customers who have not placed 
--an order.
--Join 
SELECT FirstName , LastName 
FROM Person.Person P INNER JOIN
Sales.Customer C ON
P.BusinessEntityID = C.CustomerID LEFT JOIN
Sales.SalesOrderHeader S ON
C.CustomerID = S.CustomerID
WHERE S.SalesOrderID IS NULL;

select * from Person.Person
select * from Sales.SalesOrderHeader
select * from sales.Customer


--Subquery
SELECT FirstName , LastName 
FROM Person.Person
Where BusinessEntityID IN 
	(SELECT CustomerID FROM Sales.Customer WHERE CustomerID NOT IN  
		(SELECT CustomerID FROM Sales.SalesOrderHeader));


--CTE
WITH Result (FirstName, LastName)
AS (
	SELECT P.FirstName, P.LastName
	FROM Person.Person P INNER JOIN
	Sales.Customer C ON
	P.BusinessEntityID = C.CustomerID LEFT JOIN
	Sales.SalesOrderHeader S ON
	C.CustomerID = S.CustomerID
	WHERE S.SalesOrderID IS NULL)

SELECT FirstName, LastName
FROM Result;


--EXISTS
SELECT FirstName , LastName 
FROM Person.Person P
	WHERE EXISTS (SELECT C.CustomerID
	FROM Sales.Customer C
	WHERE P.BusinessEntityID = C.CustomerID AND
		NOT EXISTS (SELECT S.CustomerID
		FROM Sales.SalesOrderHeader S
		WHERE C.CustomerID = S.CustomerID));
