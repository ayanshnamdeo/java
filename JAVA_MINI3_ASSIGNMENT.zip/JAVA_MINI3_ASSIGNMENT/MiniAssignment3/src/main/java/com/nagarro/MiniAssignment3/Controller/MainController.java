package com.nagarro.MiniAssignment3.Controller;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.MiniAssignment3.ServiceImpl.AccWeatherServiceImpl;
import com.nagarro.MiniAssignment3.ServiceImpl.CurrentWeatherServiceImpl;
import com.nagarro.MiniAssignment3.ServiceImpl.WeatherDPImpl;
import com.nagarro.MiniAssignment3.entity.AccuWeather;
import com.nagarro.MiniAssignment3.entity.CurrentWeatherCondition;
import com.nagarro.MiniAssignment3.entity.WeatherReport;
import com.nagarro.MiniAssignment3.services.AccWeatherService;
import com.nagarro.MiniAssignment3.services.CurrentWeatherService;
import com.nagarro.MiniAssignment3.services.WeatherDP;

@RestController
public class MainController {

	@Autowired
	private WeatherDP weatherDP;
	
	@Autowired
	private CurrentWeatherService currentService;
	
	@Autowired
	private AccWeatherService accService;
	
	
	//Main
	@GetMapping("/weather")
	public WeatherReport fetchReport(@RequestParam String city,@RequestParam String zip) throws InterruptedException,ExecutionException {
		return weatherDP.fetchReport(city,zip);
	}
	
	//CurrentCondition
	@GetMapping("/weatherCurrent")
	public CurrentWeatherCondition fetchReport(@RequestParam String city) {
		System.out.println("inside curr controller");
		CurrentWeatherCondition con=currentService.fetchReport(city);
		System.out.println(con);
		return con;
	}
	
	//OpenWeatherCondition
	@GetMapping("/weatherAccu")
	public AccuWeather fetchReportAcc(@RequestParam String zip) {
		return accService.fetchReport(zip);
	}
	
	
}
