package com.nagarro.MiniAssignment3.SubEntities;

import com.fasterxml.jackson.annotation.JsonProperty;


public class TemperatureType {
	
	@JsonProperty("Metric")
	private Metric Metric;

	@Override
	public String toString() {
		return "TemperatureType [Metric=" + Metric + "]";
	}

	
	
//	public Metric getMetric() {
//		return Metric;
//	}
//
//	public void setMetric(Metric metric) {
//		Metric = metric;
//	}
	
	
	
//	@JsonProperty("Imperial")
//	private TemperatureValue Imperial;
//
//	public TemperatureValue getMetric() {
//		return Metric;
//	}
//
//	public void setMetric(TemperatureValue metric) {
//		Metric = metric;
//	}
//
//	public TemperatureValue getImperial() {
//		return Imperial;
//	}
//
//	public void setImperial(TemperatureValue imperial) {
//		Imperial = imperial;
//	}
//	
//	

}
