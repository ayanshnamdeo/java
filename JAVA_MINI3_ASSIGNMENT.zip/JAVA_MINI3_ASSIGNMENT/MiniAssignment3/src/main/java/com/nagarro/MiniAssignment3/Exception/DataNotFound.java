package com.nagarro.MiniAssignment3.Exception;

public class DataNotFound extends RuntimeException  {

	public DataNotFound(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
