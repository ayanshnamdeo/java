package com.nagarro.MiniAssignment3.SubEntities;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Wind {

	@JsonProperty("speed")
	private Long speed;
	
	@JsonProperty("deg")
	private Integer deg;
	
	@JsonProperty("gust")
	private Long gust;

	public Long getSpeed() {
		return speed;
	}

	public void setSpeed(Long speed) {
		this.speed = speed;
	}

	public Integer getDeg() {
		return deg;
	}

	public void setDeg(Integer deg) {
		this.deg = deg;
	}

	public Long getGust() {
		return gust;
	}

	public void setGust(Long gust) {
		this.gust = gust;
	}
	
	
}
