package com.nagarro.MiniAssignment3.Exception;

public class NoWeatherFoundException extends RuntimeException {

	public NoWeatherFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
		

	
}
