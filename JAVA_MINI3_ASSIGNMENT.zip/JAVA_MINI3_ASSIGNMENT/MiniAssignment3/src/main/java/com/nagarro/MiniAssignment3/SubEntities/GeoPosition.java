package com.nagarro.MiniAssignment3.SubEntities;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GeoPosition {

	@JsonProperty("lat")
	private double lat;
	
	@JsonProperty("lon")
	private double lon;
	
//	@JsonProperty("Elevation")
//	private ElevationType Elevation;
	
	@JsonProperty("MobileLink")
	private String MobileLink;
	
	@JsonProperty("Link")
	private String Link;



	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLon() {
		return lon;
	}

	public void setLon(double lon) {
		this.lon = lon;
	}

//	public ElevationType getElevation() {
//		return Elevation;
//	}
//
//	public void setElevation(ElevationType elevation) {
//		Elevation = elevation;
//	}

	public String getMobileLink() {
		return MobileLink;
	}

	public void setMobileLink(String mobileLink) {
		MobileLink = mobileLink;
	}

	public String getLink() {
		return Link;
	}

	public void setLink(String link) {
		Link = link;
	}
	
	
	
}
