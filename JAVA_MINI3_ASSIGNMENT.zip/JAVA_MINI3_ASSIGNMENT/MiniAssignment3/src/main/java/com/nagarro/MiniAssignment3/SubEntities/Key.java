package com.nagarro.MiniAssignment3.SubEntities;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Key {

	@JsonProperty("Key")
	private String Key;

	public String getKey() {
		return Key;
	}

	public void setKey(String key) {
		Key = key;
	}
	
	
}
