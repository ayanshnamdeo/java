package com.nagarro.MiniAssignment3.SubEntities;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Metric {
	
	@JsonProperty("Value")
	private Long Value;
	
	@JsonProperty("Unit")
	private String Unit;
	
	@JsonProperty("UnitType")
	private Integer UnitType;

	@Override
	public String toString() {
		return "Metric [Value=" + Value + ", Unit=" + Unit + ", UnitType=" + UnitType + "]";
	}
	
	
	
//
//	public Long getValue() {
//		return Value;
//	}
//
//	public void setValue(Long value) {
//		Value = value;
//	}
//
//	public String getUnit() {
//		return Unit;
//	}
//
//	public void setUnit(String unit) {
//		Unit = unit;
//	}
//
//	public Integer getUnitType() {
//		return UnitType;
//	}
//
//	public void setUnitType(Integer unitType) {
//		UnitType = unitType;
//	}
	
	

}
