package com.nagarro.MiniAssignment3.Exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;


@ControllerAdvice
public class ResourceNotFound {

	
	@ExceptionHandler(NoWeatherFoundException.class )
	public ResponseEntity<String> handleNoUserFoundException(NoWeatherFoundException ex){
		
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(DataNotFound.class )
	public ResponseEntity<String> handleDataNotFoundException(DataNotFound ex){
		
		return new ResponseEntity<String>(ex.getMessage(),HttpStatus.NOT_FOUND);
	}
}
