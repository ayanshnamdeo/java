package com.nagarro.MiniAssignment3.services;

import org.springframework.stereotype.Service;

import com.nagarro.MiniAssignment3.entity.CurrentWeatherCondition;

@Service
public interface CurrentWeatherService {

  CurrentWeatherCondition fetchReport(String city);
}
