package com.nagarro.MiniAssignment3.services;

import org.springframework.stereotype.Service;

import com.nagarro.MiniAssignment3.entity.AccuWeather;

@Service
public interface AccWeatherService {

	public AccuWeather fetchReport(String zip);
}
