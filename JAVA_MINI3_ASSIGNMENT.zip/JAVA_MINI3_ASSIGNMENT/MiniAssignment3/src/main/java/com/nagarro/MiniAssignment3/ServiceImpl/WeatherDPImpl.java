package com.nagarro.MiniAssignment3.ServiceImpl;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.nagarro.MiniAssignment3.entity.AccuWeather;
import com.nagarro.MiniAssignment3.entity.CurrentWeatherCondition;
import com.nagarro.MiniAssignment3.entity.WeatherReport;
import com.nagarro.MiniAssignment3.services.WeatherDP;

@Component
public class WeatherDPImpl implements WeatherDP {

	@Autowired
	CurrentWeatherServiceImpl currentWeatherService;
	
	@Autowired
	AccWeatherServiceImpl accWeatherService;
//	
	@Override
	public WeatherReport fetchReport(String city,String zip) throws InterruptedException,ExecutionException {
//		CurrentWeatherCondition currentWeatherCondition=currentWeatherService.fetchReport(city);
//		AccuWeather accuWeather =accWeatherService.fetchReport(zip);
//		return weatherReportResponse(currentWeatherCondition,accuWeather);
		
		ExecutorService executorService=Executors.newFixedThreadPool(2);
		CompletableFuture<CurrentWeatherCondition> currentWeatherCondition=CompletableFuture.supplyAsync(()->currentWeatherService.fetchReport(city),executorService);
		CompletableFuture<AccuWeather> accuWeather=CompletableFuture.supplyAsync(()->accWeatherService.fetchReport(zip),executorService);
		CurrentWeatherCondition currentWeatherConditionGet=currentWeatherCondition.get();
		AccuWeather accuWeatherGet=accuWeather.get();
		return weatherReportResponse(currentWeatherConditionGet,accuWeatherGet);
	}
	
	public WeatherReport weatherReportResponse(CurrentWeatherCondition currentWeatherCondition,AccuWeather accuWeather) {
		WeatherReport weatherReport = new WeatherReport();
		weatherReport.setWeatherText(currentWeatherCondition.getWeatherText());
		weatherReport.setHasPrecipitation(currentWeatherCondition.isHasPrecipitation());
		weatherReport.setPrecipitationType(currentWeatherCondition.getPrecipitationType());
		weatherReport.setIsDayTime(currentWeatherCondition.isIsDayTime());
		weatherReport.setTemperature(currentWeatherCondition.getTemperature());
		//
		weatherReport.setMain(accuWeather.getMain());
		weatherReport.setVisibility(accuWeather.getVisibility());
		weatherReport.setWind(accuWeather.getWind());
		weatherReport.setSys(accuWeather.getSys());
		return weatherReport;
	}
	
}
