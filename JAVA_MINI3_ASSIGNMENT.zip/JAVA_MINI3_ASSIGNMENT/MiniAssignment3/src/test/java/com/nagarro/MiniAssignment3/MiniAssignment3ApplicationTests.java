package com.nagarro.MiniAssignment3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniAssignment3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
