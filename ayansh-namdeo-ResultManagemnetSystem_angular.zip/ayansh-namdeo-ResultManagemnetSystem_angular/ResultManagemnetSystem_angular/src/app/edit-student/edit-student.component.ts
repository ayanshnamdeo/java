import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms'
import { Router, ActivatedRoute } from '@angular/router'
import { StudentServiceService } from '../student-service.service'

@Component({
  selector: 'app-edit-student',
  templateUrl: './edit-student.component.html',
  styleUrls: ['./edit-student.component.css']
})
export class EditStudentComponent implements OnInit {

  constructor(private router: Router,private service: StudentServiceService, private activeRoute: ActivatedRoute) { }

  editStudent = new FormGroup({
    rollno: new FormControl('', Validators.required),
    name: new FormControl('', Validators.required),
    dob: new FormControl('', Validators.required),
    score: new FormControl('', Validators.required)
  })

  restData: any = {}

  ngOnInit(): void {
    console.log(this.activeRoute.snapshot.params['id'])
    this.service.getDataById(this.activeRoute.snapshot.params['id']).subscribe((result) => {
      this.restData = result
      this.editStudent = new FormGroup({
        rollno: new FormControl(this.restData.rollno, Validators.required),
        name: new FormControl(this.restData.name, Validators.required),
        dob: new FormControl(this.restData.dob, Validators.required),
        score: new FormControl(this.restData.score, Validators.required)
      })

      console.log(result)
    })
  }

  collectData() {
    console.log(this.editStudent.value)
    this.service.editStudent(this.activeRoute.snapshot.params['id'], this.editStudent.value).subscribe((result) => {
      if (result) {
        alert("Update Successfully")
        this.router.navigate(['/teacher/home'])
      } else {
        alert("Update Not Worked something went wrong!!!")
      }
    })

  }

  get rollno() {
    return this.editStudent.get('rollno')
  }

  get name() {
    return this.editStudent.get('name')
  }

  get dob() {
    return this.editStudent.get('dob')
  }

  get score() {
    return this.editStudent.get('score')
  }

}
