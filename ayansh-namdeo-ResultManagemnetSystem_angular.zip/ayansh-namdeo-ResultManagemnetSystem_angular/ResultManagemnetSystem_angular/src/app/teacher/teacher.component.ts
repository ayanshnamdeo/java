import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms'
import {Router} from '@angular/router'
import {StudentServiceService} from '../student-service.service'

@Component({
  selector: 'app-teacher',
  templateUrl: './teacher.component.html',
  styleUrls: ['./teacher.component.css']
})
export class TeacherComponent implements OnInit {

  constructor(private router:Router,private service:StudentServiceService) { }

  teacherLoginForm=new FormGroup({
    username:new FormControl(''),
    password:new FormControl('')
  })

  collectData(){
    this.service.getTeacherLoginDataCheck().subscribe(data=>{
      const user = data.find((u:any)=>{
        return u.username === this.teacherLoginForm.value.username && u.password === this.teacherLoginForm.value.password
      });
      if(user){
        this.teacherLoginForm.reset();
        this.router.navigate(['/teacher/home'])
      }else{
        alert("Teacher not found or enter correct credentials!!");
        this.teacherLoginForm.reset();
      }
    
    },err=>{
      alert("something went wrong!!")
    })
    
  }

  get username(){
    return this.teacherLoginForm.get('username')
  }

  get password(){
    return this.teacherLoginForm.get('password')
  }

  ngOnInit(): void {
  }

}
