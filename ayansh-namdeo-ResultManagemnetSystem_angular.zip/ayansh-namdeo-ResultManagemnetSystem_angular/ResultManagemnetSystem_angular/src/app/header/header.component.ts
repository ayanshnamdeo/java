import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  header = 'Result Management System';

  constructor() {}

  inLoginPage: Boolean = false;

  onClickHome = () => {
    this.inLoginPage = true;
  };

  ngOnInit(): void {}
}
