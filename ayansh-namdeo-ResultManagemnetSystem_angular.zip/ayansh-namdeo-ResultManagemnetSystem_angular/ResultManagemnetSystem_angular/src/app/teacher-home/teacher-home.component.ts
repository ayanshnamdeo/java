import { Component, OnInit } from '@angular/core';
import {StudentServiceService} from '../student-service.service'
import {Router} from '@angular/router'

@Component({
  selector: 'app-teacher-home',
  templateUrl: './teacher-home.component.html',
  styleUrls: ['./teacher-home.component.css']
})
export class TeacherHomeComponent implements OnInit {

  constructor(private student:StudentServiceService,private router:Router) { }
  collect:any;

  del(item:number){

    this.student.deleteStudent(item).subscribe((result)=>{
      if(result){
        alert("Deleted Successfully!!!")
        this.ngOnInit()
      }
      else{
        alert("Deletion Not Worked!!!")
      }
    })

  }

  ngOnInit(): void {

    this.student.getList().subscribe((data)=>{
      this.collect=data
    })

  }

}
