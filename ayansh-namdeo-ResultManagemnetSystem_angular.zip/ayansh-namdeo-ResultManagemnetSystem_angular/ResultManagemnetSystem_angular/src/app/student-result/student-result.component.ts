import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router'
import { StudentServiceService } from '../student-service.service'


@Component({
  selector: 'app-student-result',
  templateUrl: './student-result.component.html',
  styleUrls: ['./student-result.component.css']
})
export class StudentResultComponent implements OnInit {

  constructor(private service: StudentServiceService,private activeRoute: ActivatedRoute) {
  }

  restData: any = {}

  ngOnInit(): void {
    this.service.getDataById(this.activeRoute.snapshot.params['id']).subscribe((result) => {

      this.restData = result

    })
  }


}
