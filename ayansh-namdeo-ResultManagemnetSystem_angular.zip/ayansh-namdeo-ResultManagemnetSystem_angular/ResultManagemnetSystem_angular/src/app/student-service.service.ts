import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentServiceService {

  studentDataUrl = "http://localhost:3001/StudentData"

  studentLoginUrl = "http://localhost:3002/StudentLoginData"

  teacherLoginUrl = "http://localhost:3003/TeacherLoginData"

  constructor(private http: HttpClient) { }

  getTeacherLoginDataCheck(): Observable<any> {
    return this.http.get(this.teacherLoginUrl)
  }

  getStudentLoginDataCheck(): Observable<any> {
    return this.http.get(this.studentLoginUrl)
  }

  getDataCheck(): Observable<any> {
    return this.http.get(this.studentDataUrl);
  }

  getList() {
    // console.log(this.http.get(this.url))
    return this.http.get(this.studentDataUrl)
  }

  addStudent(data: any) {
    return this.http.post(this.studentDataUrl, data)
  }

  

  deleteStudent(data: number) {
    return this.http.delete(`${this.studentDataUrl}/${data}`)
  }

  getDataById(data: number) {
    return this.http.get(`${this.studentDataUrl}/${data}`)
  }

  editStudent(data: number, formData: any) {
    return this.http.put(`${this.studentDataUrl}/${data}`, formData)
  }

}
