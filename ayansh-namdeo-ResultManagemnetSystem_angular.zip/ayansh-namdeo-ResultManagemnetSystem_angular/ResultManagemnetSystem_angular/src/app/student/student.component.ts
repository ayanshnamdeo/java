import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentServiceService } from '../student-service.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css'],
})
export class StudentComponent implements OnInit {
  constructor(private router: Router, private service: StudentServiceService) {}

  inLoginPage: Boolean = true;

  studentLoginForm = new FormGroup({
    username: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  });

  collectData() {
    //console.log(this.studentLoginForm.value);
    this.service.getStudentLoginDataCheck().subscribe(
      (data) => {
        const user = data.find((u: any) => {
          return (
            u.username === this.studentLoginForm.value.username &&
            u.password === this.studentLoginForm.value.password
          );
        });
        if (user) {
          this.studentLoginForm.reset();
          this.router.navigate(['/student/home']);
        } else {
          alert('student not found and enter correct credentials!!!');
          this.studentLoginForm.reset();
        }
      },
      (err) => {
        alert('something went wrong!!');
      }
    );
  }

  get username() {
    return this.studentLoginForm.get('username');
  }

  get password() {
    return this.studentLoginForm.get('password');
  }

  ngOnInit(): void {}
}
