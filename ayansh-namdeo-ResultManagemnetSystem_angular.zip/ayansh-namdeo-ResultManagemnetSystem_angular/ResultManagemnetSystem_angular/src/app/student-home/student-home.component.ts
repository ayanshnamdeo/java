import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentServiceService } from '../student-service.service';

@Component({
  selector: 'app-student-home',
  templateUrl: './student-home.component.html',
  styleUrls: ['./student-home.component.css'],
})
export class StudentHomeComponent implements OnInit {
  constructor(private router: Router, private service: StudentServiceService) {}
  restData: any = {};

  inLoginPage: Boolean = true;

  studentHome = new FormGroup({
    rollno: new FormControl('', Validators.required),
    dob: new FormControl('', Validators.required),
  });

  collectData() {
    this.service.getDataCheck().subscribe(
      (data) => {
        const result = data.find((u: any) => {
          return (
            u.rollno === this.studentHome.value.rollno &&
            u.dob === this.studentHome.value.dob
          );
        });
        if (result) {
          this.router.navigate([
            '/student/home/result',
            this.studentHome.value.rollno,
          ]);
        } else {
          alert('Data Not Found & please enter correct Data');
          this.studentHome.reset();
        }
      },
      (err) => {
        alert('something went wrong!!');
      }
    );
  }

  get rollno() {
    return this.studentHome.get('rollno');
  }

  get dob() {
    return this.studentHome.get('dob');
  }

  ngOnInit(): void {}
}
