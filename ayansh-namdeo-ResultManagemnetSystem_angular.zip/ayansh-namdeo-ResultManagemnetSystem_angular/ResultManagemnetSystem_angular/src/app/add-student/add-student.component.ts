import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentServiceService } from '../student-service.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css'],
})
export class AddStudentComponent implements OnInit {
  constructor(private router: Router, private service: StudentServiceService) {}

  addStudent = new FormGroup({
    rollno: new FormControl('', Validators.required),
    name: new FormControl('', Validators.required),
    dob: new FormControl('', Validators.required),
    score: new FormControl('', Validators.required),
  });

  collectData() {
    this.service.addStudent(this.addStudent.value).subscribe(
      (user) => {
        if (user) {
          alert('Added Successfully');
          this.router.navigate(['/teacher/home']);
        } else {
          alert('Data not added Something went wrong!!');
        }
      },
      (err) => {
        alert('student already exist...');
      }
    );
  }

  ngOnInit(): void {}

  get rollno() {
    return this.addStudent.get('rollno');
  }

  get name() {
    return this.addStudent.get('name');
  }

  get dob() {
    return this.addStudent.get('dob');
  }

  get score() {
    return this.addStudent.get('score');
  }
}
