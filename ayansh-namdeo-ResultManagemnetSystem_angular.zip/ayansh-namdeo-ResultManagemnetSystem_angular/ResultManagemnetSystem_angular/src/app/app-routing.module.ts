import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginPageComponent } from './login-page/login-page.component';
import { StudentComponent } from './student/student.component';
import { TeacherComponent } from './teacher/teacher.component';
import { ErrorPageComponent } from './error-page/error-page.component';
import { StudentHomeComponent } from './student-home/student-home.component';
import { TeacherHomeComponent } from './teacher-home/teacher-home.component';
import { StudentResultComponent } from './student-result/student-result.component';
import { AddStudentComponent } from './add-student/add-student.component';
import { EditStudentComponent } from './edit-student/edit-student.component';

const routes: Routes = [
  {
    path: '',
    component: LoginPageComponent,
  },
  {
    path: 'student',
    children: [
      {
        path: '',
        component: StudentComponent,
      },
      {
        path: 'home',
        children: [
          {
            path: '',
            component: StudentHomeComponent,
          },
          {
            path: 'result/:id',
            component: StudentResultComponent,
          },
        ],
      },
    ],
  },
  {
    path: 'teacher',
    children: [
      {
        path: '',
        component: TeacherComponent,
      },
      {
        path: 'home',
        children: [
          {
            path: '',
            component: TeacherHomeComponent,
          },
          {
            path: 'add',
            component: AddStudentComponent,
          },
          {
            path: 'edit/:id',
            component: EditStudentComponent,
          },
        ],
      },
    ],
  },
  {
    path: '**',
    component: ErrorPageComponent,
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
