package com.nagarro.exitdemapi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nagarro.exitdemapi.entity.PinCode;

public interface PinCodeDao extends JpaRepository<PinCode, Long> {

	public PinCode findByPincode(Long pincode);

	public List<PinCode> findByPincodeAndProductCode(Long pincode, Integer productCode);

	public PinCode getProductsByPincodeAndProductCode(Long pincode, Integer productCode);
}
