package com.nagarro.exitdemapi.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.nagarro.exitdemapi.entity.UserReg;



public interface UserDao extends JpaRepository<UserReg, Integer>  {


	public UserReg findByEmail(String email);

}
