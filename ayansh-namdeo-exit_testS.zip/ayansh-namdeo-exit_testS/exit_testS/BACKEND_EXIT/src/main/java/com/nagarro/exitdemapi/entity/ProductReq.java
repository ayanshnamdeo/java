package com.nagarro.exitdemapi.entity;

public class ProductReq {
	int productCode;
	String brand;
	String name;
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ProductReq(int productCode, String brand, String name) {
		super();
		this.productCode = productCode;
		this.brand = brand;
		this.name = name;
	}
	
}
