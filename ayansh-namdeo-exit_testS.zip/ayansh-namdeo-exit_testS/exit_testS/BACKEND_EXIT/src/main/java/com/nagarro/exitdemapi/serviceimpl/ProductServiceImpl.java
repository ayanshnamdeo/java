package com.nagarro.exitdemapi.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nagarro.exitdemapi.dao.ProductDao;
import com.nagarro.exitdemapi.entity.Products;
import com.nagarro.exitdemapi.service.ProductService;

@Component
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductDao productDao;
	
	
	
	

//	public ProductServiceImpl(ProductDao productDao) {
//		super();
//		this.productDao = productDao;
//	}
	@Override
    public Products getProductByProductCode(int productCode) {
        if (this.productDao.existsById(productCode)) {
        	System.out.println("fetch get by code ayansh");
            Products getProductByProductCode=this.productDao.findByProductCode(productCode);
            return getProductByProductCode;
        }
        else {
            return null;
        }
    }

    @Override
    public List<Products> getProductByName(String name) {
        List<Products> allProductsByName=
                this.productDao.getProductsByName(name);
        if(allProductsByName.size()==0) {
            return null;
        }
        else {
            return allProductsByName;
        }
    }

    @Override
    public List<Products> getProductByBrand(String brand) {
        List<Products> allProductsByName=
                this.productDao.getProductsByBrand(brand);
        if(allProductsByName.size()==0) {
            return null;
        }
        else {
            return allProductsByName;
        }
    }
    


	@Override
	public Products addProduct(Products product) {
		// TODO Auto-generated method stub
		//return productDao.save(product);
		productDao.save(product);
		return product;
	}



	@Override
	public List<Products> fetchProductByProductCodeAndNameAndBrand(int productCode,String name,String brand) {
		// TODO Auto-generated method stub
		System.out.println("Ayansh inside implementation"+brand+name+productCode);
		return productDao.findByProductCodeAndNameAndBrand(productCode,name,brand);
	}

	@Override
	public List<Products> getAllProducts() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	@Override
	public List<Products> getProduct() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Products> getProduct(int productCode, String name, String brand) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Products saveproduct(Products product) {
		// TODO Auto-generated method stub
		return  productDao.save(product);
	}

	@Override
	public List<Products> getCode() {
		// TODO Auto-generated method stub
		return productDao.findAll();
	}

	




	
	
	
}
