package com.nagarro.exitdemapi.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class PinCode {

	@Id
	private Long pincode;
	private String message;
	private int productCode;
	
	public PinCode() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PinCode(Long pincode, String message,int productCode) {
		super();
		this.pincode = pincode;
		this.message = message;
		this.productCode=productCode;
	}

	public Long getPincode() {
		return pincode;
	}

	public void setPincode(Long pincode) {
		this.pincode = pincode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}

	
	@Override
	public String toString() {
		return "PinCode [pincode=" + pincode + ", message=" + message + ", productCode=" + productCode + "]";
	}
	


}
