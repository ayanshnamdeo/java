package com.nagarro.exitdemapi.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;

@Entity
public class Products {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productCode;
	
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String description;
	@Lob
	private byte[] image;
	private int price;
	private String brand;
	
	
	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Products(int productCode, String name, String description, byte[] image, int price, String brand) {
		super();
		this.productCode = productCode;
		this.name = name;
		this.description = description;
		this.image = image;
		this.price = price;
		this.brand = brand;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
}
	@Override
	public String toString() {
		return "Products [productCode=" + productCode + ", name=" + name + ", description=" + description + ", image="
				+ image + ", price=" + price + ", brand=" + brand + "]";
	}
	
	
	
}


