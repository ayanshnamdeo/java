package com.nagarro.exitdemapi.controller;

import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.nagarro.exitdemapi.entity.ProductReq;
import com.nagarro.exitdemapi.entity.Products;
import com.nagarro.exitdemapi.entity.UserReg;
import com.nagarro.exitdemapi.service.ProductService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@GetMapping("/produ")
	public List<Products> getCode(){
		
		
		return this.productService.getCode();
		
	}



	@PostMapping("/addproduct")
	public Products addProduct(@RequestParam(value = "productCode") int productCode, @RequestParam(value = "name") String name,
            @RequestParam(value = "brand") String brand, @RequestParam(value = "price") int price,
            @RequestParam(value = "image") MultipartFile file, @RequestParam(value = "description") String description) throws Exception {


	       Products product = new Products();
	        product.setProductCode(productCode);
	        product.setName(name);
	        product.setBrand(brand);
	        product.setPrice(price);
	        InputStream is = file.getInputStream();
	        byte data[] = new byte[is.available()];
	        is.read(data);
	        product.setImage(data);
	        product.setDescription(description);
	        Products productObj = null;
	        if (productCode != 0 && !"".equals(productCode)) {
	            productObj = productService.getProductByProductCode(productCode);
	            if (productObj != null) {
	                throw new Exception("Product is already in database");
	            }
	        }
	        productObj = productService.saveproduct(product);
	        return productObj;
	    }
	
	
	


//imp code

	@GetMapping("/getproduct/{productCode}")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<Products> getProductByProductCode(@PathVariable int productCode) {
		Products getproduct = productService.getProductByProductCode(productCode);
		if (getproduct != null) {
			return new ResponseEntity<Products>(getproduct, HttpStatus.OK);
		} else {
			return new ResponseEntity<Products>(HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/getproducts")
	public List<Products> SearchProduct(@RequestBody Products products) throws Exception {
		String tempbrand = products.getBrand();
		String tempname = products.getName();
		int tempcode = products.getProductCode();
		System.out.println("Ayansh Get" + tempbrand + tempname + tempcode);
//    	String tempbrand="Jockey";
//    	String tempname="Shoes";
//    	int tempcode=7;
		List<Products> productobj = null;
		if (tempbrand != null && tempname != null && tempcode != 0) {
			productobj = productService.fetchProductByProductCodeAndNameAndBrand(tempcode, tempname, tempbrand);
		} else if (productobj == null) {
			System.out.println(productobj);
			throw new Exception("Invalid Credentials");

		}
		return productobj;
	}

	
	
	@PostMapping("/getproducts")
	public List<Products> SearchProductPost(@RequestBody ProductReq productDetails) throws Exception {
		String tempbrand = productDetails.getBrand();
		String tempname = productDetails.getName();
		int tempcode = productDetails.getProductCode();
		System.out.println("Ayansh Post" + tempbrand + tempname + tempcode);
//     	String tempbrand="Jockey";
//     	String tempname="Shoes";
//     	int tempcode=7;
		List<Products> productobj = null;
		if (tempbrand != null && tempname != null && tempcode != 0) {
			productobj = productService.fetchProductByProductCodeAndNameAndBrand(tempcode, tempname, tempbrand);}
		
		else if (productobj == null) {
			throw new Exception("Invalid Credentials");
		}
		return productobj;
	}


	@GetMapping("/getallproductsbyname")
	public ResponseEntity<List<Products>> getProductByName(@RequestParam("name") String name) {
		List<Products> allProductsByName = productService.getProductByName(name);
		System.out.println(" Finded");
		if (allProductsByName == null) {
			System.out.println("Not Finded");
			return new ResponseEntity<List<Products>>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<List<Products>>(allProductsByName, HttpStatus.OK);
		}
	}
	
	@GetMapping("/getallproductsbybrand")
	public ResponseEntity<List<Products>> getProductByBrand(@RequestParam("brand") String brand) {
		List<Products> allProductsByBrand = productService.getProductByBrand(brand);
		System.out.println("Not Finded");
		if (allProductsByBrand == null) {
			System.out.println("Not Finded");
			return new ResponseEntity<List<Products>>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<List<Products>>(allProductsByBrand, HttpStatus.OK);
		}

	}
	


	}

