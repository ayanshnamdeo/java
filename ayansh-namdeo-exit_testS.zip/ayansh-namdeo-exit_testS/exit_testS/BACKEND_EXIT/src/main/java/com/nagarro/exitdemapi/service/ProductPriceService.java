package com.nagarro.exitdemapi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarro.exitdemapi.entity.Products;

@Service
public interface ProductPriceService {

//	List<Products> getProductPriceDetails();

	//Products getProductPriceByProductCode(int productCode);

	List<Products> getProductPriceByName(String name);

	List<Products> getProductPriceByBrand(String brand);

	Products findByCode(int productCode);

//	List<Products> findByName(String name);

	

}
