package com.nagarro.exitdemapi.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nagarro.exitdemapi.dao.ProductDao;
import com.nagarro.exitdemapi.dao.ProductDetailDao;
import com.nagarro.exitdemapi.entity.Products;
import com.nagarro.exitdemapi.service.ProductDetailService;

@Component
public class ProductDetailServiceImpl implements ProductDetailService {

	@Autowired
	ProductDetailDao productDetailDao;

	@Override
	public List<Products> getProductDetails() {
		// TODO Auto-generated method stub
		return productDetailDao.findAll();
	}
	
}
