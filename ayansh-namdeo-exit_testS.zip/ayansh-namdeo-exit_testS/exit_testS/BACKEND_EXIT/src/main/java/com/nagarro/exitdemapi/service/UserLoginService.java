package com.nagarro.exitdemapi.service;

import org.springframework.stereotype.Service;

import java.util.List;
import com.nagarro.exitdemapi.entity.UserReg;

@Service
public interface UserLoginService {
	
	public UserReg fetchUserByEmailAndPassword(String email,String password);
	

}
