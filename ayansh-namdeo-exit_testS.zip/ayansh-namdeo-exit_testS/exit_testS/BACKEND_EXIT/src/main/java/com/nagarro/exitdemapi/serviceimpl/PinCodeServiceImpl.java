package com.nagarro.exitdemapi.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.nagarro.exitdemapi.dao.PinCodeDao;
import com.nagarro.exitdemapi.entity.PinCode;
import com.nagarro.exitdemapi.entity.Products;
import com.nagarro.exitdemapi.service.PinCodeService;

@Component
public class PinCodeServiceImpl implements PinCodeService {
	@Autowired
	private PinCodeDao pinCodeDao;

	@Override
	public PinCode getPincode(Long pincode) {

		PinCode pinObj = pinCodeDao.findByPincode(pincode);
		return pinObj;
	}

	@Override
	public PinCode addPin(PinCode pinCode) {
		pinCodeDao.save(pinCode);
		return pinCode;
	}

	@Override
	public List<PinCode> pinCodes() {
		// TODO Auto-generated method stub
		return (List<PinCode>) pinCodeDao.findAll();
	}

	@Override
	public List<PinCode> fetchProductByPincodeAndProductCode(Long pincode, Integer productCode) {
		// TODO Auto-generated method stub
		return pinCodeDao.findByPincodeAndProductCode(pincode, productCode);
	}

	@Override
	public PinCode getProductByPincodeAndProductCode(Long pincode, Integer productCode) {
		// TODO Auto-generated method stub
		PinCode allpin = this.pinCodeDao.getProductsByPincodeAndProductCode(pincode, productCode);
		if (pincode == 0 && productCode==0) {
			return null;
		} else {
			return allpin;
		}
	}

}
