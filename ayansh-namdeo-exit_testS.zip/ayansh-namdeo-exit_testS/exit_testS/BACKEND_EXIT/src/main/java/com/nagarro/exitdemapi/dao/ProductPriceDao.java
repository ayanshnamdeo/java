package com.nagarro.exitdemapi.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nagarro.exitdemapi.entity.Products;

public interface ProductPriceDao extends JpaRepository<Products, Integer> {

	List<Products> getProductPriceByBrand(String brand);

	List<Products> getProductPriceByName(String name);


	

	
}
