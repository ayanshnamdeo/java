package com.nagarro.exitdemapi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarro.exitdemapi.entity.UserReg;

@Service
public interface UserService {

	public UserReg addUser(UserReg userReg);
	
	
	public UserReg fetchUserByEmail(String email);

}
