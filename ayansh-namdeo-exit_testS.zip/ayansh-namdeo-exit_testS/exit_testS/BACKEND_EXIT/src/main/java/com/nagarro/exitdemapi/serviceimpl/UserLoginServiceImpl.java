package com.nagarro.exitdemapi.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nagarro.exitdemapi.dao.UserLoginDao;

import com.nagarro.exitdemapi.entity.UserReg;
import com.nagarro.exitdemapi.service.UserLoginService;

@Component
public class UserLoginServiceImpl implements UserLoginService {

	@Autowired
	UserLoginDao userLoginDao;
	
	@Override
	public UserReg fetchUserByEmailAndPassword(String email,String password) {
		// TODO Auto-generated method stub
		System.out.println("hii inside impl"+email+password);
		return userLoginDao.findByEmailAndPassword(email,password);
	}

	
}