package com.nagarro.exitdemapi.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nagarro.exitdemapi.entity.Products;

public interface ProductDetailDao extends JpaRepository<Products, Integer>{

}
