package com.nagarro.exitdemapi.service;

import java.util.List;

import org.springframework.stereotype.Service;


import com.nagarro.exitdemapi.entity.PinCode;

@Service
public interface PinCodeService {
	public PinCode getPincode(Long pincode);

	public PinCode addPin(PinCode pinCode);

	public List<PinCode> pinCodes();

	public List<PinCode> fetchProductByPincodeAndProductCode(Long pincode, Integer productCode);

	public PinCode getProductByPincodeAndProductCode(Long pincode, Integer productCode);
}
