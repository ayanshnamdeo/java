package com.nagarro.exitdemapi.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import com.nagarro.exitdemapi.dao.UserDao;
import com.nagarro.exitdemapi.entity.UserReg;
import com.nagarro.exitdemapi.service.UserService;

@Component
public class UserServiceImpl implements UserService {
	@Autowired
	UserDao userDao;



	@Override
	public UserReg addUser(UserReg userReg) {
		// TODO Auto-generated method stub
		userDao.save(userReg);
		return userReg;
	}



	@Override
	public UserReg fetchUserByEmail(String email) {
		// TODO Auto-generated method stub
		return userDao.findByEmail(email);
	}
	

}
