package com.nagarro.exitdemapi.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.nagarro.exitdemapi.entity.UserReg;

public interface UserLoginDao extends JpaRepository<UserReg, Integer> {

	public UserReg findByEmailAndPassword(String email,String password);

	
}
