package com.nagarro.exitdemapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExitdemapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExitdemapiApplication.class, args);
	}

}
