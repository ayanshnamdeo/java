package com.nagarro.exitdemapi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nagarro.exitdemapi.entity.Products;

@Repository
public interface ProductDao extends JpaRepository<Products, Integer>  {

	public List<Products> getProductsByName(String name);

	public List<Products> getProductsByBrand(String brand);


	

	public List<Products> findByProductCodeAndNameAndBrand(int productCode, String name,String brand);

	public Products findByProductCode(int productCode);





	

}
