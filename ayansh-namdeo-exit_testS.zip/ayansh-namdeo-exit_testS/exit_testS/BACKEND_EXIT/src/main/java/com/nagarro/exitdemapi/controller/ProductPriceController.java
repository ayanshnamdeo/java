package com.nagarro.exitdemapi.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.exitdemapi.entity.Products;
import com.nagarro.exitdemapi.service.ProductPriceService;
import com.nagarro.exitdemapi.service.ProductService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ProductPriceController {
	@Autowired
	private ProductPriceService productPriceService;
	
	    
	 @GetMapping("/getproductprice/{productCode}")
		public int getPrice(@PathVariable("productCode") int productCode) {
			Products products=productPriceService.findByCode(productCode);
			return products.getPrice();
		}
		
	
	 

	    @GetMapping("/getallproductspricebyname/{name}")
	    @CrossOrigin(origins="http://localhost:4200")
	    public ResponseEntity<List<Products>> getProductPriceByName(@PathVariable String name){
	        List<Products> allProductsByName=productPriceService.getProductPriceByName(name);
	       
	        if(allProductsByName==null) {
	            System.out.println("Not Finded");
	            return new ResponseEntity<List<Products>>(HttpStatus.NOT_FOUND);
	        }
	        else {
	            return new ResponseEntity<List<Products>>(allProductsByName,HttpStatus.OK);
	        }
	    }
	 

	 

	    @GetMapping("/getallproductspricebybrand/{brand}")
	    @CrossOrigin(origins="http://localhost:4200")
	    public ResponseEntity<List<Products>> getProductPriceByBrand(@PathVariable String brand){
	        List<Products> allProductsByBrand=productPriceService.getProductPriceByBrand(brand);
	        System.out.println("Not Finded");
	        if(allProductsByBrand==null) {
	          
	            return new ResponseEntity<List<Products>>(HttpStatus.NOT_FOUND);
	        }
	        else {
	            return new ResponseEntity<List<Products>>(allProductsByBrand,HttpStatus.OK);
	        }
	    
	 
		}

}
