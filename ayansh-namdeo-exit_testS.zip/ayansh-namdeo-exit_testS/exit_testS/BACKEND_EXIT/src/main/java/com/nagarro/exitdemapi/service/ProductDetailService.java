package com.nagarro.exitdemapi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarro.exitdemapi.entity.Products;

@Service
public interface ProductDetailService {

	public List<Products> getProductDetails();

}
