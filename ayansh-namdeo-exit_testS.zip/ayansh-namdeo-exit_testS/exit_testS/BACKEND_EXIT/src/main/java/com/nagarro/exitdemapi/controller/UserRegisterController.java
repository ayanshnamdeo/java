package com.nagarro.exitdemapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.exitdemapi.entity.UserReg;
import com.nagarro.exitdemapi.service.UserService;



@RestController
@CrossOrigin(origins="http://localhost:4200")
public class UserRegisterController {

	@Autowired
	private UserService userService;
	
	

	@PostMapping("/registeruser")
	public UserReg addUser(@RequestBody UserReg userReg) throws Exception {
		 String tempEmail=userReg.getEmail();
		if(tempEmail !=null && !"".equals(tempEmail)) {
			UserReg userobj=userService.fetchUserByEmail(tempEmail);
			if(userobj !=null) {
				throw new Exception("User with"+tempEmail+"Is Already Exist");
				}
		}
		UserReg userobj=null;
		userobj=userService.addUser(userReg);
		return userobj;

	}



	
}
