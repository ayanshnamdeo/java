package com.nagarro.exitdemapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nagarro.exitdemapi.entity.PinCode;
import com.nagarro.exitdemapi.entity.Products;
import com.nagarro.exitdemapi.service.PinCodeService;
import com.nagarro.exitdemapi.service.UserLoginService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class PinCodeController {

	@Autowired
	private PinCodeService pinCodeService;
	

	
 @PostMapping(path = "/checkservice", consumes = "application/json")
 @CrossOrigin(origins="http://localhost:4200")
	public PinCode addPin(@RequestBody PinCode pinCode) {
		return pinCodeService.addPin(pinCode);

	}
	
	@GetMapping("/checkservice/{pincode}")
	@CrossOrigin(origins="http://localhost:4200")
	public PinCode getProductBypincode(@PathVariable("pincode") Long pincode) throws Exception {

		PinCode pin = this.pinCodeService.getPincode(pincode);
		if (pin == null) {

			System.out.println("Pincode not found");

		}

		return pin;

	}
	@GetMapping("/checkservice")
	public List<PinCode> getPinCode() {
		return this.pinCodeService.pinCodes();
	}

  @GetMapping("/getpincode")
	@CrossOrigin(origins="http://localhost:4200")
	public List<PinCode> GetpinCodeByPincodeAndproductCode(@RequestBody PinCode pincodes) throws Exception {
		Long pincode =pincodes.getPincode();
		Integer productCode = pincodes.getProductCode();
		List<PinCode> pincodeobj=null;
		if(pincode != null && productCode !=null ) {
			 pincodeobj=pinCodeService.fetchProductByPincodeAndProductCode(pincode,productCode);
		}
		if(pincodeobj==null) {
			throw new Exception("Invalid PinCode ");
		}
		return pincodeobj;
	}
  
 	@GetMapping("/getbypinandcode")
	public ResponseEntity<PinCode> getProductByPincodeAndProductCode(@RequestParam("pincode") Long pincode,@RequestParam("productCode") Integer productCode) {
		PinCode pin = pinCodeService.getProductByPincodeAndProductCode(pincode,productCode);
		System.out.println(" Finded");
		if (pin == null) {
			System.out.println("Not Finded");
			return new ResponseEntity<PinCode>(HttpStatus.NOT_FOUND);
		} else {
			return new ResponseEntity<PinCode>(pin , HttpStatus.OK);
		}
	}
}
