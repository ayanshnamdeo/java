package com.nagarro.exitdemapi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.nagarro.exitdemapi.entity.Products;

@Service
public interface ProductService {
	
	public List<Products> getAllProducts();
	
	Products addProduct(Products product);

	List<Products> getProductByBrand(String brand);


	
	List<Products> getProductByName(String name);
	

	Products getProductByProductCode(int productCode);



	List<Products> fetchProductByProductCodeAndNameAndBrand(int productCode, String name,String brand);

	public List<Products> getProduct();

	public List<Products> getProduct(int productCode, String name, String brand);

	public Products saveproduct(Products product);

	public List<Products> getCode();

	


	
}