package com.nagarro.exitdemapi.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nagarro.exitdemapi.dao.ProductPriceDao;
import com.nagarro.exitdemapi.entity.Products;
import com.nagarro.exitdemapi.service.ProductPriceService;

@Component
public class ProductPriceServiceImpl implements ProductPriceService {

	@Autowired
	ProductPriceDao productPriceDao;
	

	@Override
	public Products findByCode(int productCode) {
		// TODO Auto-generated method stub
	
		if(this.productPriceDao.existsById(productCode)) {
			Products getProductByProductCode=this.productPriceDao.findById(productCode).get();
           return getProductByProductCode;
		}
		else {
		return null;
	}
	}
	



	@Override
	public List<Products> getProductPriceByName(String name) {
		// TODO Auto-generated method stub
		 List<Products> allProductsByName=
	                this.productPriceDao.getProductPriceByName(name);
	        if(allProductsByName.size()==0) {
	            return null;
	        }
	        else {
	            return allProductsByName;
	        }
	}
	


	@Override
	public List<Products> getProductPriceByBrand(String brand) {
		// TODO Auto-generated method stub
		 List<Products> allProductsByName=
	                this.productPriceDao.getProductPriceByBrand(brand);
	        if(allProductsByName.size()==0) {
	            return null;
	        }
	        else {
	            return allProductsByName;
	        }
	}

	

	



}
