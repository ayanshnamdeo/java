package com.nagarro.exitdemapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExitdemapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
