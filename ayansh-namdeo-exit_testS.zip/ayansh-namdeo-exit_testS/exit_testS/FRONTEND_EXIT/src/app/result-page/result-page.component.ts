import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../product';
import { RegistrationService } from '../registration.service';
import { DomSanitizer } from '@angular/platform-browser';
import { User } from '../user';
import { Pincode } from '../pincode';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
@Component({
  selector: 'app-result-page',
  templateUrl: './result-page.component.html',
  styleUrls: ['./result-page.component.css']
})
export class ResultPageComponent implements OnInit {
  
  constructor(private service:RegistrationService,private activeRoute: ActivatedRoute,private sanitizer:DomSanitizer) { }
  collection:any=[];
  products:any=new Product();
  codes:any=new Pincode();
  cod:any=[];
  
  des:any=[];
  msg="";
   show:Boolean=false;
   imageSrc:any
   searchpinForm= new FormGroup({
    brand: new FormControl('', Validators.required)
  });
   getImage(image:any)



   {
       let objectURL = 'data:image/png;base64,' + image;
   
   
   
       this.imageSrc = this.sanitizer.bypassSecurityTrustUrl(objectURL);
   }
  ngOnInit(): void {
    
    
    console.log("Hello bai"+this.activeRoute.snapshot.params['productCode']);
     this.service.getDataByProductCode(this.activeRoute.snapshot.params['productCode']).subscribe((res) => {
        
      console.log(res);
        this.collection = res;
        console.warn(this.collection);
    })
  
}
showMe:boolean=false;
showdescription(){
  this.showMe=!this.showMe
  console.log("Hiiiii"+this.products.name+"ye le"+this.activeRoute.snapshot.params['name'])
  console.log("mila kya"+this.collection.productCode);
  this.des=this.collection;
  console.log("des"+this.collection.name);
}
searchpin(){
  console.log("not find collection->"+this.codes.productCode)
  console.log("cod-->"+this.cod.pincode+this.cod.productCode)
  console.log("Hiiiii pincode"+this.codes.pincode+"productcode by code"+this.codes.productCode)
  this.service.getpin(this.codes.pincode,this.codes.productCode).subscribe(
    (data) => {

      if(this.codes.product === this.collection.productCode){
      console.log("response Recieved")
      alert("find Successfully")
      console.log(data);
      this.collection = data;
      console.warn(this.cod);
      this.searchpinForm.reset();
      }
    
    },
    error =>{
      alert("not find"+this.cod.pincode+this.cod.productCode)
      this.msg="Not Delieverd at this location /pincode address"
      this.collection=null;
      this.searchpinForm.reset();
      }
  )
    }
  }
