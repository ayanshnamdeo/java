import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Product } from '../product';
import { RegistrationService } from '../registration.service';


@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private service:RegistrationService,private activeRoute: ActivatedRoute) { }
  collection:any=[];
  products:any=new Product();
  ngOnInit(): void {
    console.log("Hiiiii"+this.products.name+"ye le"+this.activeRoute.snapshot.params['name'])
    this.service.searchbyname(this.products.name).subscribe(
      (data) => {
        console.log("response Recieved")
        alert("find Successfully")
        console.log(data);
        this.collection= data;
        console.warn(this.collection);
       
      
      },
      error =>{
        alert("Not Find this type Of Product")
        this.collection=null;
        
        }
         
    )
  }
 
  

}
