import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { FormGroup, FormControl, Validators, MinValidator, MaxLengthValidator, MinLengthValidator } from '@angular/forms';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {
  product :any;
  products=new Product();
  collection:any=[];
  temp:any=[];
  des:any=[];
  imageSrc:any
  code:number=0;
  filteredProducts : any = [];
  getImage(image:any)
{
    let objectURL = 'data:image/png;base64,' + image;
    this.imageSrc = this.sanitizer.bypassSecurityTrustUrl(objectURL);
}
  msg="";
  searchForm = new FormGroup({
  productCode:new FormControl('', Validators.required),
   name: new FormControl('', Validators.required),
   brand: new FormControl('', Validators.required),
 });
 searchhomeForm = new FormGroup({
  name: new FormControl('', Validators.required)
});
searchhomebrandForm= new FormGroup({
 brand: new FormControl('', Validators.required)
});


filterForm=new FormGroup({
 min: new FormControl(0, [Validators.required,Validators.minLength(500)]),
 max: new FormControl(0, [Validators.required,Validators.maxLength(10000)]),
});
  constructor(private service:RegistrationService,private router:Router,private activeRoute: ActivatedRoute,private sanitizer:DomSanitizer,private http:HttpClient) { }

  
  ngOnInit(): void {
   this.search();
  }
  search(){
    this.service.search().subscribe((resp:Product[])=>
    {
      this.collection=resp;
      console.log(resp);
    },
    (error:HttpErrorResponse)=>{
      console.log(error);
    }
    );
  }


  searchproduct(searchForm:NgForm){
    this.service.searchproductFromRemote(this.products).subscribe(
      data => {
        console.warn("response Recieved"+this.searchForm.value.productCode+"kemm"+this.products.productCode)
        alert("Searching Element Detectede"+JSON.stringify(data))
        console.log(data);
        this.collection = data;
        this.code=this.products.productCode;
        console.log("code value os"+this.code);
          // this.router.navigate(['/result-page'])
        this.router.navigate(['/result-page',this.products.productCode]);
        this.searchForm.reset();
       
    
      },
      error =>{
         console.log("exception occured",this.products.productCode)
         alert("This Search Is not valid ,try with other Product name and brand")
         this.collection=null;
        //  this.msg="bad search,please enter Valid brand and product name"
        //  this.router.navigate(['/product-search'])
          this.searchForm.reset();
        }
         
    )
  }
  searchhomeproduct(searchhomeForm:NgForm){
    console.log("Hiiiii BY NAME:="+this.products.name)
    this.service.searchbyname(this.products.name).subscribe(
      (data) => {
        console.log("response Recieved");
        alert("find Successfully")
        console.log(data)
        console.log("amit");
        this.collection = data;
        console.log("mila kya name"+this.collection);
         this.searchhomeForm.reset();
      
      },
      error =>{
        alert("Not Find this type Of Product")
        this.collection=null;
        this.searchhomeForm.reset();
        }
         
    )
  }
  searchhomebrandproduct(searchhomebrandForm:NgForm){
    console.log("Hiiiii"+this.products.brand)
    this.service.searchbybrand(this.products.brand).subscribe(
      (data) => {
        console.log("response Recieved")
        alert("find Successfully")
        console.log(data);
        this.collection = data;
        console.warn(this.collection);
        this.searchhomeForm.reset();
      
      },
      error =>{
        alert("Not Find this type Of Product")
        this.collection=null;
        this.searchhomeForm.reset();
        }
         
    )
  
  }

 


  get productCode() {
        return this.searchForm.get('productCode');
      }
    
      get name() {
        return this.searchForm.get('name');
      }
    
      get brand() {
        return this.searchForm.get('brand');
      }
    

      filterByLevis(){
        for(let j of this.collection){
          if(j.brand =="levis"){
            this.temp.push(j);
          }
        }
        this.collection = this.temp;
      }
      filterByAdidas(){
        for(let j of this.collection){
          if(j.brand =="Adidas"){
            this.temp.push(j);
           }
          
        }
        this.collection = this.temp;
      }
      filterByWrong(){
        for(let j of this.collection){
          if(j.brand =="wrong"){
            this.temp.push(j);
          }
        }
        this.collection = this.temp;
      }
      filterByAsics(){
        for(let j of this.collection){
          if(j.brand =="Asics"){
            this.temp.push(j);
          }
        }
        this.collection = this.temp;
      }

      filterByPrice(){
      

        let min= this.filterForm.value.min;
    
        let max = this.filterForm.value.max;
        
        console.log(min,max);
        for(let product of this.collection){
    
          if(product.price>=0 && product.price<=2000){
    
            this.filteredProducts.push(product);
    
          }
    
        }
    
        this.collection = this.filteredProducts;
        this.filterForm.reset();
      }

  
}
 


//   get productCode() {
//     return this.searchForm.get('productCode');
//   }

//   get name() {
//     return this.searchForm.get('name');
//   }

//   get brand() {
//     return this.searchForm.get('brand');
//   }


// }
