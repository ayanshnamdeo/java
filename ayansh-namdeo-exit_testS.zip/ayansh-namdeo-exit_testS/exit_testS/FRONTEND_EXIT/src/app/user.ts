
export class User {
     id:number=0;
    email:string='';
    password:string='';
    conpassword:string='';
    firstname:string='';
    lastname:string='';

    // id:any;
    // email:any;
    // password:any;
    // conpassword:any;
    // firstname:any;
    // lastname:any;
    
    constructor(){
    
    }
   
     
}

