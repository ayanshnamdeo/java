import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  user=new User();
  msg="";
  constructor(private service:RegistrationService,private router:Router) { }

  ngOnInit(): void {
  }
  registeruser(registerForm:NgForm){
    this.service.registerUserFromRemote(this.user).subscribe(
      data => {
        console.log("response Recieved")
        alert("Register Successfully")
        this.router.navigate([''])
        registerForm.reset();
      
      },
      error =>{
         console.log("exception occured")
         alert("registration Failed")
         this.msg="This Email Already In Used"
         registerForm.reset();
         this.router.navigate(['/registeruser'])
         
        }
         
    )
  }
}
