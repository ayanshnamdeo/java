import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Route, Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';
import { FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

   user=new User();
   msg="";
   loginForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
  });
  
  constructor(private service:RegistrationService,private router:Router) { 
    // localStorage.clear();
  }

  ngOnInit(): void {
  }
  loginuser(loginForm:NgForm){
    this.service.loginUserFromRemote(this.user).subscribe(
      data => {
        console.log("response Recieved")
        // this.loginForm=this.loginForm.value.email;
          // user.studentLoginForm=this.studentLoginForm.value.password;
        // localStorage.setItem('email',);
        // localStorage.setItem('password',this.user.email);
        // localStorage.setItem('password',this.user.password);
        alert("Authentication Successfully")
        this.router.navigate(['/product-search'])
        loginForm.reset();
       
      
      },
      error =>{
         console.log("exception occured")
         alert("Authentication Failed")
         this.msg="bad credentials,please enter valid email password"
         this.router.navigate([''])
         loginForm.reset();
        }
         
    )
  }
  get email() {
    return this.loginForm.get('email');
  }

  get password() {
    return this.loginForm.get('password');
  }
}
