import { Pincode } from './pincode';

describe('Pincode', () => {
  it('should create an instance', () => {
    expect(new Pincode()).toBeTruthy();
  });
});
