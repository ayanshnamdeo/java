export class Pincode {
    pincode:number=0;
    message:string='';
    productCode:number=0;
   

    constructor(){

    }
}
