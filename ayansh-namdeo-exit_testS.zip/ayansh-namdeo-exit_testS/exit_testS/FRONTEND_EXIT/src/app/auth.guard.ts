// import { Injectable } from '@angular/core';
// import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
// import { Observable } from 'rxjs';
// import { RegistrationService } from './registration.service';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthGuard implements CanActivate {
//   constructor( private authService: RegistrationService,
//     private router: Router){

//     }
//   canActivate(
//     route: ActivatedRouteSnapshot,
//     state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
//     // return true;
//     var isAuthenticated = this.authService.isUserLoggedIn();
//     if (!isAuthenticated) {
//       //localStorage.setItem();
//       console.log("Not Authenticated");
//         this.router.navigate(['']);
        
//         return false;
//     }
//     return isAuthenticated;
//   }
  
// }
