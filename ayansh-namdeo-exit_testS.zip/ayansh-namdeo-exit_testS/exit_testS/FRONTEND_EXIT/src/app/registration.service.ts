import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import{HttpClient,HttpClientModule, HttpParams} from '@angular/common/http'
import { User } from './user';
import { Product } from './product';
@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
 
  constructor(private http:HttpClient) { }

  url="http://localhost:8083/getproduct";
  bynameurl="http://localhost:8083/getallproductsbyname";
  bycodeurl="http://localhost:8083/getproductbycode"; 
  bybrandurl="http://localhost:8083/getallproductsbybrand";
  bypinurl="http://localhost:8083/getbypinandcode";
  
  public loginUserFromRemote(user: User):Observable<any>{
    return this.http.post<any>("http://localhost:8083/login",user);
  }
  public registerUserFromRemote(user: User):Observable<any>{
    return this.http.post<any>("http://localhost:8083/registeruser",user);
  }
  // public searchproductFromRemote(products: Product):Observable<any>{
  //   return this.http.post<any>("http://localhost:8083/getproduct",products);
  // }
   public searchproductFromRemote(product:Product):Observable<any>{
    return this.http.get<any>("http://localhost:8083/getproduct/"+product.productCode);
  }
  
   public  getList():Observable<any>{
    return this.http.get("http://localhost:8083/getproducts");
  }
  getDataByProductCode(data: number){
    return this.http.get(`${this.url}/${data}`)
  }
  search():Observable<any>{
    return this.http.get<Product[]>("http://localhost:8083/produ");
  }
  getpin(data1:any,data2:any){
    let querrypin = new HttpParams();
    let querrypro = new HttpParams();
    querrypin = querrypin.append('pincode',data1);
    querrypro = querrypro.append('productCode',data2);
    return this.http.get(`${this.bypinurl}`,{
      params:querrypin,
    })
  }

  searchbyname(data:any){
    let querryprams = new HttpParams();
    querryprams = querryprams.append('name',data);
    return this.http.get(`${this.bynameurl}`,{
      params:querryprams,
    })
  }
  searchbybrand(data:any){
    let querryprams = new HttpParams();
    querryprams = querryprams.append('brand',data);
    return this.http.get(`${this.bybrandurl}`,{
      params:querryprams,
  })
}

  searchbycode(data:any){
    let querryprams = new HttpParams();
    querryprams = querryprams.append('productCode',data);
    return this.http.get(`${this.bycodeurl}`,{
      params:querryprams,
    })
  }
 
  isUserLoggedIn(){
    return(
      localStorage.getItem('email')!=null &&
      localStorage.getItem('password')!=null
    );
  }
 

}
