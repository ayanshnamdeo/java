import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Product } from '../product';
import { RegistrationService } from '../registration.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  product :any;
  products=new Product();
  msg="";
  searchhomeForm = new FormGroup({
   name: new FormControl('', Validators.required)
 });
 searchhomebrandForm= new FormGroup({
  brand: new FormControl('', Validators.required)
});


  constructor(private service:RegistrationService,private router:Router,private sanitizer:DomSanitizer) { }

  ngOnInit(): void {
  }
  collection:any=[]
  imageSrc:any

  getImage(image:any)
{
    let objectURL = 'data:image/png;base64,' + image;
    this.imageSrc = this.sanitizer.bypassSecurityTrustUrl(objectURL);
}


  searchhomeproduct(searchhomeForm:NgForm){
    console.log("Hiiiii"+this.products.name)
    this.service.searchbyname(this.products.name).subscribe(
      (data) => {
        console.log("response Recieved")
        alert("find Successfully")
        console.log(data);
        this.collection = data;
        console.warn(+this.collection);
        this.searchhomeForm.reset();
      
      },
      error =>{
        alert("Not Find this type Of Product")
        this.collection=null;
        this.searchhomeForm.reset();
        }
         
    )
  }
  searchhomebrandproduct(searchhomebrandForm:NgForm){
    console.log("Hiiiii"+this.products.brand)
    this.service.searchbybrand(this.products.brand).subscribe(
      (data) => {
        console.log("response Recieved")
        alert("find Successfully")
        console.log(data);
        this.collection = data;
        console.warn(this.collection);
        this.searchhomeForm.reset();
      
      },
      error =>{
        alert("Not Find this type Of Product")
        this.collection=null;
        this.searchhomeForm.reset();
        }
         
    )
  
  }
}
