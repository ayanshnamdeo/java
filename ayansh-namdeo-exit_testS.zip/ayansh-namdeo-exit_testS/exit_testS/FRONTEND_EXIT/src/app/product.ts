export class Product {

    
    productCode:number=0;
    name:string='';
    brand:string='';
    description:string='';
    image:string='';
    price:string='';
   

    constructor(){

    }
     
}

