import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { AuthGuard } from './auth.guard';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { ProductSearchComponent } from './product-search/product-search.component';
import { RegistrationComponent } from './registration/registration.component';
import { ResultPageComponent } from './result-page/result-page.component';

const routes: Routes = [
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:"product-search",
    component:ProductSearchComponent,
    // canActivate:[AuthGuard]

  },
  {
    path:"registeruser",
    component:RegistrationComponent
  },
  {
    path:"product-details",
    component:ProductDetailsComponent,
    
  },
  {
     path:"result-page/:productCode",
    // path:"result-page",
    component:ResultPageComponent
  },
  {
    path:'',
    component:HomeComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
