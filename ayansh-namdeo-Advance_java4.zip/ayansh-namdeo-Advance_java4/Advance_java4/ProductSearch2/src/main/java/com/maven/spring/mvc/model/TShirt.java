package com.maven.spring.mvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnTransformer;

import com.maven.spring.mvc.enums.TShirtColour;
import com.maven.spring.mvc.enums.TShirtGenderRecommendation;
import com.maven.spring.mvc.enums.TShirtSize;

//ensure hibernate that this is entity class
@Entity
@Table(name = "tshirt")
public class TShirt {

	// If table column name is same as entity class field no need to use @Column
	// annotation

	// @Id is used to declare primary key for that object

	// @GeneratedValue(strategy = GenerationType.IDENTITY) : if want to auto
	// increment the id field
	@Id
	@Column(name = "tshirt_id")
	private String tShirtId;

	@Column(name = "tshirt_name")
	private String tShirtName;

	@Column(name = "tshirt_colour")
	@ColumnTransformer(read = "UPPER(tshirt_colour)")
	@Enumerated(EnumType.STRING)
	private TShirtColour tShirtColour;

	@Column(name = "tshirt_gender")
	private TShirtGenderRecommendation tShirtGenderRecommendation;

	@Column(name = "tshirt_size")
	private TShirtSize tShirtSize;

	@Column(name = "tshirt_price")
	private Double tShirtPrice;

	@Column(name = "tshirt_rating")
	private Double tShirtRating;

	@Column(name = "tshirt_availability")
	private Character tShirtAvailability;

	public TShirt(TShirtColour tShirtColour, TShirtGenderRecommendation tShirtGenderRecommendation, TShirtSize tShirtSize) {
		super();
		this.tShirtColour = tShirtColour;
		this.tShirtGenderRecommendation = tShirtGenderRecommendation;
		this.tShirtSize = tShirtSize;
	}

	public TShirt() {
		super();
	}

	public TShirt(String tShirtId, String tShirtName, TShirtColour tShirtColour, TShirtGenderRecommendation tShirtGenderRecommendation,
			TShirtSize tShirtSize, Double tShirtPrice, Double tShirtRating, Character tShirtAvailability) {
		super();
		this.tShirtId = tShirtId;
		this.tShirtName = tShirtName;
		this.tShirtColour = tShirtColour;
		this.tShirtGenderRecommendation = tShirtGenderRecommendation;
		this.tShirtSize = tShirtSize;
		this.tShirtPrice = tShirtPrice;
		this.tShirtRating = tShirtRating;
		this.tShirtAvailability = tShirtAvailability;
	}

	/**
	 * @return the tShirtId
	 */
	public String gettShirtId() {
		return tShirtId;
	}

	/**
	 * @param tShirtId the tShirtId to set
	 */
	public void settShirtId(String tShirtId) {
		this.tShirtId = tShirtId;
	}

	/**
	 * @return the tShirtName
	 */
	public String gettShirtName() {
		return tShirtName;
	}

	/**
	 * @param tShirtName the tShirtName to set
	 */
	public void settShirtName(String tShirtName) {
		this.tShirtName = tShirtName;
	}

	/**
	 * @return the tShirtColour
	 */
	public TShirtColour gettShirtColour() {
		return tShirtColour;
	}

	/**
	 * @param tShirtColour the tShirtColour to set
	 */
	public void settShirtColour(TShirtColour tShirtColour) {
		this.tShirtColour = tShirtColour;
	}

	/**
	 * @return the tShirtGenderRecommendation
	 */
	public TShirtGenderRecommendation gettShirtGenderRecommendation() {
		return tShirtGenderRecommendation;
	}

	/**
	 * @param tShirtGenderRecommendation the tShirtGenderRecommendation to set
	 */
	public void settShirtGenderRecommendation(TShirtGenderRecommendation tShirtGenderRecommendation) {
		this.tShirtGenderRecommendation = tShirtGenderRecommendation;
	}

	/**
	 * @return the tShirtSize
	 */
	public TShirtSize gettShirtSize() {
		return tShirtSize;
	}

	/**
	 * @param tShirtSize the tShirtSize to set
	 */
	public void settShirtSize(TShirtSize tShirtSize) {
		this.tShirtSize = tShirtSize;
	}

	/**
	 * @return the tShirtPrice
	 */
	public Double gettShirtPrice() {
		return tShirtPrice;
	}

	/**
	 * @param tShirtPrice the tShirtPrice to set
	 */
	public void settShirtPrice(Double tShirtPrice) {
		this.tShirtPrice = tShirtPrice;
	}

	/**
	 * @return the tShirtRating
	 */
	public Double gettShirtRating() {
		return tShirtRating;
	}

	/**
	 * @param tShirtRating the tShirtRating to set
	 */
	public void settShirtRating(Double tShirtRating) {
		this.tShirtRating = tShirtRating;
	}

	/**
	 * @return the tShirtAvailability
	 */
	public Character gettShirtAvailability() {
		return tShirtAvailability;
	}

	/**
	 * @param tShirtAvailability the tShirtAvailability to set
	 */
	public void settShirtAvailability(Character tShirtAvailability) {
		this.tShirtAvailability = tShirtAvailability;
	}

	@Override
	public String toString() {
		return "[ID= " + tShirtId + ", Name= " + tShirtName + ", Colour= " + tShirtColour + ", GenderRecommendation= "
				+ tShirtGenderRecommendation + ", Size= " + tShirtSize + ", Price= " + tShirtPrice + ", Rating= "
				+ tShirtRating + ", Availability= " + tShirtAvailability + "]";
	}

}
