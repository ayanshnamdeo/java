package com.maven.spring.mvc.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.maven.spring.mvc.dao.TShirtDAOService;
import com.maven.spring.mvc.model.TShirt;

@Controller
@RequestMapping(value = "/tshirt")
public class TShirtController {

	@Autowired
	private TShirtDAOService tshirtDao;

	@RequestMapping("/get-tshirt")
	public void getAllDataFromTable(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView mv = new ModelAndView();

		List<TShirt> list = tshirtDao.getAllTShirt();

		mv.setViewName("user-home");

		HttpSession session = request.getSession();

		if (list != null) {
			session.setAttribute("user_list", list);
		} else {
			session.setAttribute("user_list", list);
		}

	}

	@RequestMapping("/save-tshirt")
	public boolean saveTShirtData() {

		File files[] = new File("src//main//resources//csv_files").listFiles();

		System.out.println(files == null);

		boolean isSaved = tshirtDao.saveTShirt(files);

		return isSaved;

	}

	@RequestMapping("/get-matched")
	public void getMatchedTShirt(HttpServletRequest request, HttpServletResponse response) {

		String color = request.getParameter("color");
		String size = request.getParameter("size");
		String gender = request.getParameter("gender");
		String output = request.getParameter("output");

		if (color.equals("SELECT")) {
			color = null;
		}
		if (size.equals("SELECT")) {
			size = null;
		}
		if (gender.equals("SELECT")) {
			gender = null;
		}

//		TShirt tshirt = new TShirt(TShirtColour.valueOf(color), TShirtGenderRecommendation.valueOf(gender), TShirtSize.valueOf(size), TShirtOutputPreference.valueOf(output));

		HttpSession session = request.getSession();

		List<TShirt> list = (List<TShirt>) session.getAttribute("user_list");

		List<TShirt> matched = tshirtDao.getAllMatchedTShirt(color, size, gender, output);

		session.removeAttribute("user_list");

		session.setAttribute("user_list", matched);

	}

}
