package com.maven.spring.mvc.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class HibernateUtil {

	private HibernateUtil() {

	}

	private static EntityManager manager;

	public static EntityManager getManager() {
		try {
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("TShirt_details");

			if(manager == null)
				manager = emf.createEntityManager();
			else
				return manager;

			return manager;
		}catch(Exception ex){
			ex.printStackTrace();
			return manager;
		}
	}

}
