package com.maven.spring.mvc.enums;

public enum TShirtOutputPreference {

	RATING, PRICE, BOTH

}
