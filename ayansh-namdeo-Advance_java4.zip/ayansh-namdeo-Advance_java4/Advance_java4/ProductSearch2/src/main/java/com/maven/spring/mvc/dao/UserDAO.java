package com.maven.spring.mvc.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import org.springframework.stereotype.Component;

import com.maven.spring.mvc.exception.AdminNotExistException;
import com.maven.spring.mvc.model.User;
import com.maven.spring.mvc.util.EncryptPasswordWithMD;
import com.maven.spring.mvc.util.HibernateUtil;


@Component
public class UserDAO implements UserDAOService{

	private EntityManager manager;

	public UserDAO() {
		super();
		manager = HibernateUtil.getManager();
	}

	public User checkAdminIsPresent(User user) {

		User returnValidUser = null;

		// get md5 hash form of login password which will check with existing password
		// if user is present...
		String passwordToMatch = EncryptPasswordWithMD.getPasswordEncrypted(user.getPassword().toCharArray());
		String existingPassword = "";

		try {

			// start the transaction
			EntityTransaction transaction = manager.getTransaction();

			transaction.begin();

			// get admin for that particular id
			User presentUser = manager.find(User.class, user.getEmail());

			transaction.commit();

			// check if admin is not present then throw our customized exception
			// AdminNotExistException....
			if (presentUser == null)
				throw new AdminNotExistException("no admin exist with this email '" + user.getEmail() + "'");
			else {
				// get md5 hash form of existing admin password
				existingPassword = presentUser.getPassword();

				System.out.println(existingPassword + " " + passwordToMatch);

				// here we chech if user is present is it password correct or not...
				if (existingPassword.compareTo(passwordToMatch) == 0)
					returnValidUser = presentUser;
				return returnValidUser;
			}

		} catch (AdminNotExistException ex) {
			System.out.println(ex); // print the exception to the console
			return returnValidUser;
		}

	}

}
