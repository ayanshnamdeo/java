package com.maven.spring.mvc.dao;

import java.io.File;
import java.util.List;

import com.maven.spring.mvc.model.TShirt;

public interface TShirtDAOService {

	
	public boolean saveTShirt(File[] files);
	
	public List<TShirt> getAllTShirt();
	
	public List<TShirt> getAllMatchedTShirt(String color, String size, String gender, String output);
	
}
