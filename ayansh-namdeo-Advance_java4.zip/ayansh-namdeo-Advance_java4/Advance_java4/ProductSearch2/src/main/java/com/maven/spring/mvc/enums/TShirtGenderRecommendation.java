package com.maven.spring.mvc.enums;

public enum TShirtGenderRecommendation {
	
	M, F, U
	
}
