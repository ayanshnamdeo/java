package com.maven.spring.mvc.exception;

@SuppressWarnings("serial")
public class FileNotExistException extends RuntimeException {
	
	String message;
	
	public FileNotExistException(String message) {
		this.message = message;
	}
	
	public String toString() {
		return "FileNotExistException exception raised at line " + this.getStackTrace()[1].getLineNumber() + " and at line "
				+ this.getStackTrace()[0].getLineNumber() + " : '"+message+"'";
	}
}
