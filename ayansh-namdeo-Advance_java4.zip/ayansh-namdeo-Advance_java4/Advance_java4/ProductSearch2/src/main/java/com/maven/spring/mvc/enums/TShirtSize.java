package com.maven.spring.mvc.enums;

public enum TShirtSize {
	S, M, L, XL
}
