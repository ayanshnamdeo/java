package com.maven.spring.mvc;



import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import com.maven.spring.mvc.enums.TShirtColour;
import com.maven.spring.mvc.enums.TShirtGenderRecommendation;
import com.maven.spring.mvc.enums.TShirtSize;
import com.maven.spring.mvc.model.TShirt;
import com.maven.spring.mvc.util.HibernateUtil;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

public class MainApp {

	public static void main(String[] args) throws NumberFormatException, CsvValidationException, IOException {

		EntityManager manager = HibernateUtil.getManager();

		

//		User user = new User("user@gmail.com", EncryptPasswordWithMD.getPasswordEncrypted("Pass@123".toCharArray()));


		File files[] = new File("src//main//resources//csv_files").listFiles();

		String nextLine[];
		TShirt tShirt;
		List<TShirt> list = new ArrayList<TShirt>();

		for (File file : files) {

			CSVReader reader = new CSVReaderBuilder(new FileReader(file)).withSkipLines(1).build();

			while ((nextLine = reader.readNext()) != null) {

				tShirt = new TShirt(nextLine[0], nextLine[1], TShirtColour.valueOf(nextLine[2].toUpperCase()),
						TShirtGenderRecommendation.valueOf(nextLine[3].toUpperCase()),
						TShirtSize.valueOf(nextLine[4].toUpperCase()), Double.parseDouble(nextLine[5]),
						Double.parseDouble(nextLine[6]), nextLine[7].charAt(0));
				
				System.out.println(tShirt);
				
				manager.getTransaction().begin();

				manager.merge(tShirt);
				
				manager.getTransaction().commit();
			}
		}


	}
}
