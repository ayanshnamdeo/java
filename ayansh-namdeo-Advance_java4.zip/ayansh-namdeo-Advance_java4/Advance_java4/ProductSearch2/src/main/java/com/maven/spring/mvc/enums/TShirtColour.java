package com.maven.spring.mvc.enums;

public enum TShirtColour {

	BLACK, WHITE, BLUE, PURPLE, GREY, PINK, YELLOW, MAROON

}
