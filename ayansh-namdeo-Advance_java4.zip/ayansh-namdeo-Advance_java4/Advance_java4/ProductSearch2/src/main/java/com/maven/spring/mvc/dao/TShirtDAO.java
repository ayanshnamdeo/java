package com.maven.spring.mvc.dao;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.maven.spring.mvc.enums.TShirtColour;
import com.maven.spring.mvc.enums.TShirtGenderRecommendation;
import com.maven.spring.mvc.enums.TShirtSize;
import com.maven.spring.mvc.exception.FileNotExistException;
import com.maven.spring.mvc.model.TShirt;
import com.maven.spring.mvc.util.HibernateUtil;
import com.maven.spring.mvc.util.MyComparator;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

@Component
public class TShirtDAO implements TShirtDAOService{

	private EntityManager manager;

	public TShirtDAO() {
		super();
		manager = HibernateUtil.getManager();
	}

	public boolean saveTShirt(File[] files) {
		String[] nextLine;
		TShirt tShirt;
		try {
			for (File file : files) {

				CSVReader reader = new CSVReaderBuilder(new FileReader(file)).withSkipLines(1).build();

				while ((nextLine = reader.readNext()) != null) {

					tShirt = new TShirt(nextLine[0], nextLine[1], TShirtColour.valueOf(nextLine[2].toUpperCase()),
							TShirtGenderRecommendation.valueOf(nextLine[3].toUpperCase()),
							TShirtSize.valueOf(nextLine[4].toUpperCase()), Double.parseDouble(nextLine[5]),
							Double.parseDouble(nextLine[6]), nextLine[7].charAt(0));

					saveDataToTable(tShirt);
				}
			}

			return true;

		} catch (FileNotExistException | CsvValidationException | IOException ex) {
			System.out.println(ex);
			return false;
		}

	}

	private void saveDataToTable(TShirt tShirt) {

		try {
			EntityManager manager = HibernateUtil.getManager();

			manager.getTransaction().begin();

			manager.merge(tShirt);

			manager.getTransaction().commit();

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public List<TShirt> getAllTShirt() {
		EntityManager manager = HibernateUtil.getManager();

		manager.getTransaction().begin();

		List<TShirt> list = manager.createQuery("from TShirt", TShirt.class).getResultList();

		manager.getTransaction().commit();

		return list;
	}

	public List<TShirt> getAllMatchedTShirt(String color, String size, String gender, String output) {

		List<TShirt> match = new ArrayList<>();

		System.out.println(color + size + gender);
		
		EntityManager manager = HibernateUtil.getManager();

		manager.getTransaction().begin();

		List<TShirt> list = manager.createQuery("from TShirt", TShirt.class).getResultList();

		manager.getTransaction().commit();

		Iterator<TShirt> iterator = list.iterator();
		while (iterator.hasNext()) {
			TShirt customer = iterator.next();

			if (gender != null && size != null && color != null) {
				if (color.equals(customer.gettShirtColour().name()) && size.equals(customer.gettShirtSize().name())
						&& gender.equals(customer.gettShirtGenderRecommendation().name()))
					match.add(customer);
				;
				continue;
			}

			if (color == null && size == null && gender == null) {
				match.add(customer);
				;
				continue;
			}
			if (color == null && size == null) {
				if (gender.equals(customer.gettShirtGenderRecommendation().name()))
					match.add(customer);
				;
				continue;
			}
			if (color == null && gender == null) {
				if (size.equals(customer.gettShirtSize().name()))
					match.add(customer);
				;
				continue;
			}
			if (size == null && gender == null) {
				if (color.equals(customer.gettShirtColour().name()))
					match.add(customer);
				;
				continue;
			}
			if (color == null && size != null && gender != null) {
				if (size.equals(customer.gettShirtSize().name())
						&& gender.equals(customer.gettShirtGenderRecommendation().name()))
					match.add(customer);
				;
				continue;
			}
			if (size == null && color != null && gender != null) {
				if (gender.equals(customer.gettShirtGenderRecommendation().name())
						&& color.equals(customer.gettShirtColour().name()))
					match.add(customer);
				;
				continue;
			}
			if (gender == null && size != null && color != null) {
				if (color.equals(customer.gettShirtColour().name()) && size.equals(customer.gettShirtSize().name()))
					match.add(customer);
				;
				continue;
			}
		}

		if (output != null) {
			Collections.sort(match, new MyComparator(output));
			return match;
		} else {
		return match;
		}

	}

}
