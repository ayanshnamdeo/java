package com.maven.spring.mvc.util;

import java.util.Comparator;

import com.maven.spring.mvc.model.TShirt;

public class MyComparator implements Comparator<TShirt> {

	private String outputPreferences;

	public MyComparator(String output) {
		this.outputPreferences = output;
	}

	@Override
	public int compare(TShirt o1, TShirt o2) {
		int c = 0;
		if (outputPreferences.equalsIgnoreCase("rating"))
			return o2.gettShirtRating().compareTo(o1.gettShirtRating());
		else if (outputPreferences.equalsIgnoreCase("price"))
			return o1.gettShirtPrice().compareTo(o2.gettShirtPrice());
		else if (outputPreferences.equalsIgnoreCase("both")) {
			c = o2.gettShirtRating().compareTo(o1.gettShirtRating());

			if (c != 0) {
				return c;
			}
			return o1.gettShirtPrice().compareTo(o2.gettShirtPrice());
		}
		return c;
	}

}
