package com.maven.spring.mvc.dao;

import com.maven.spring.mvc.model.User;

public interface UserDAOService {
	
	public User checkAdminIsPresent(User user);
	
	
	
}
