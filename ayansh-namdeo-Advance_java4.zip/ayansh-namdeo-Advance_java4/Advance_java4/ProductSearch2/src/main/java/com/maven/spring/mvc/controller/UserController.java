package com.maven.spring.mvc.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.maven.spring.mvc.dao.UserDAO;
import com.maven.spring.mvc.dao.UserDAOService;
import com.maven.spring.mvc.model.User;

import com.maven.spring.mvc.util.DisplayMessageToJSP;;

@Controller
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	private UserDAOService userDao;

	@RequestMapping("/login")
	public ModelAndView login(@ModelAttribute User user) {

		User isPresent;
		ModelAndView mv = new ModelAndView();

		isPresent = userDao.checkAdminIsPresent(user);

		if (isPresent != null) {
			mv.setViewName("user-home");
			mv.addObject("user", user);

		} else {
			DisplayMessageToJSP message = new DisplayMessageToJSP("Invalid Admin Credential ! try with another",
					"error", "alert-danger");
			mv.setViewName("index");
			mv.addObject("message", message);
		}

		return mv;
	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws IOException {

		request.removeAttribute("user/logout");
		//request.removeAttribute("user");
		DisplayMessageToJSP message = new DisplayMessageToJSP("Logout Successfully ! ", "error", "alert-success");
		ModelAndView mv = new ModelAndView();

		
		mv.setViewName("index");
		mv.addObject("message", message);
		
		return mv;

	}

	}

